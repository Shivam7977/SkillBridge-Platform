import os
import uuid
import datetime
from fastapi import FastAPI, UploadFile, File, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse

from app.config import settings
from app.models.schemas import (
    PaperAnalysisResponse,
    PaperMetadata,
    SectionData,
    TextAnalysisRequest
)
from app.services import (
    PDFExtractor,
    SectionParser,
    PaperSummarizer,
    HypothesisDetector,
    CitationAnalyzer,
    ReadabilityAnalyzer,
    KeywordExtractor,
    get_sample_analysis
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Intelligent Academic Research Paper Analyzer API for PDF parsing, NLP summarization, hypothesis detection, citation extraction, and readability evaluation."
)

# Configure CORS for React frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def run_analysis_pipeline(full_text: str, filename: str, file_size_kb: float, metadata_dict: dict = None) -> PaperAnalysisResponse:
    """Executes the full NLP & structural analysis pipeline on extracted paper text."""
    if not full_text or len(full_text.strip()) < 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The document does not contain enough extractable text. Please ensure it is not an image-only scanned PDF."
        )

    # 1. Section Parsing
    sections_raw = SectionParser.parse_sections(full_text)

    # 2. Section Summarization
    processed_sections = {}
    for sec_name, sec_dict in sections_raw.items():
        summary, key_sents = PaperSummarizer.summarize_section(sec_dict["text"], max_sentences=3)
        processed_sections[sec_name] = SectionData(
            name=sec_dict["name"],
            title=sec_dict["title"],
            text=sec_dict["text"],
            word_count=sec_dict["word_count"],
            summary=summary,
            key_sentences=key_sents,
            reading_time_min=sec_dict["reading_time_min"]
        )

    # 3. Overall Summarization & Contributions
    intro_text = processed_sections.get("Introduction", {}).text if "Introduction" in processed_sections else ""
    executive_summary = PaperSummarizer.generate_executive_summary(sections_raw, full_text)
    contributions = PaperSummarizer.extract_contributions(full_text, intro_text)

    # 4. Hypothesis & Research Question Detection
    hypothesis_data = HypothesisDetector.analyze(full_text, sections_raw)

    # 5. Citation & Bibliography Extraction
    citations_data = CitationAnalyzer.analyze(full_text, sections_raw)

    # 6. Readability & Writing Assessment
    readability_data = ReadabilityAnalyzer.evaluate(full_text, sections_raw)

    # 7. Keyword & Technical Concept Mining
    key_terms = KeywordExtractor.extract(full_text, sections_raw, top_k=24)

    # 8. Metadata Assembly
    words_total = len(full_text.split())
    chars_total = len(full_text)
    est_reading_time = round(words_total / 200.0, 1)

    title = (metadata_dict.get("title") if metadata_dict else None) or filename.rsplit('.', 1)[0].replace('_', ' ').replace('-', ' ').title()
    authors = (metadata_dict.get("authors") if metadata_dict else []) or []
    pages = (metadata_dict.get("pages") if metadata_dict else 1) or 1
    year = (metadata_dict.get("year") if metadata_dict else None)

    metadata = PaperMetadata(
        title=title,
        authors=authors,
        year=year,
        pages=pages,
        word_count=words_total,
        char_count=chars_total,
        estimated_reading_time_min=est_reading_time,
        file_name=filename,
        file_size_kb=round(file_size_kb, 1),
        extracted_sections_count=len([s for s in processed_sections.values() if s.word_count > 0])
    )

    analysis_id = f"paper-{uuid.uuid4().hex[:10]}"
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

    return PaperAnalysisResponse(
        id=analysis_id,
        timestamp=timestamp,
        metadata=metadata,
        executive_summary=executive_summary,
        key_contributions=contributions,
        sections=processed_sections,
        hypothesis=hypothesis_data,
        citations=citations_data,
        readability=readability_data,
        key_terms=key_terms,
        raw_text_preview=full_text[:1500] + ("..." if len(full_text) > 1500 else "")
    )


@app.get("/api/health")
async def health_check():
    """Health check endpoint confirming API status and active services."""
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "features": [
            "PDF Text & Layout Extraction (PyMuPDF)",
            "Section Classification (Abstract, Intro, Method, Results, Conclusion, References)",
            "Extractive Summarization & Contribution Mining",
            "Hypothesis & Research Question Detection",
            "Citation Context Explorer & Reference Matching",
            "Readability Metrics & Actionable Suggestions",
            "Multi-word Concept & Keyword Mining"
        ]
    }


@app.get("/api/sample", response_model=PaperAnalysisResponse)
async def get_sample_paper():
    """Returns a rich, instant analysis of 'Attention Is All You Need' for demonstration without file upload."""
    sample_data = get_sample_analysis()
    return JSONResponse(content=sample_data)


@app.post("/api/analyze", response_model=PaperAnalysisResponse)
async def analyze_pdf(file: UploadFile = File(...)):
    """
    Upload a research paper PDF for deep extraction and analysis.
    Supported extensions: .pdf, .txt
    """
    filename = file.filename or "uploaded_paper.pdf"
    ext = os.path.splitext(filename)[1].lower()

    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format '{ext}'. Please upload a PDF (.pdf) or text (.txt) file."
        )

    try:
        content_bytes = await file.read()
        file_size_kb = len(content_bytes) / 1024.0

        if len(content_bytes) > settings.MAX_FILE_SIZE_BYTES:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File exceeds maximum allowed size of {settings.MAX_FILE_SIZE_BYTES // (1024 * 1024)}MB."
            )

        if ext == ".pdf":
            full_text, metadata_dict, structured_blocks = PDFExtractor.extract(content_bytes, filename)
        else:
            full_text = content_bytes.decode("utf-8", errors="replace")
            metadata_dict = {"title": filename.rsplit('.', 1)[0], "authors": [], "pages": 1}

        analysis_result = run_analysis_pipeline(full_text, filename, file_size_kb, metadata_dict)
        return analysis_result

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Analysis failed: {str(e)}"
        )


@app.post("/api/analyze-text", response_model=PaperAnalysisResponse)
async def analyze_raw_text(req: TextAnalysisRequest):
    """Analyze raw academic text or manuscript drafts without requiring a PDF file."""
    if not req.text or len(req.text.strip()) < 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Text must contain at least 50 characters for meaningful academic analysis."
        )

    file_size_kb = len(req.text.encode("utf-8")) / 1024.0
    metadata_dict = {"title": req.title or "Manuscript Analysis", "authors": [], "pages": 1}

    return run_analysis_pipeline(req.text, req.file_name or "manuscript.txt", file_size_kb, metadata_dict)


@app.get("/api/download-zip")
@app.get("/download-zip")
async def download_project_zip():
    """Download the complete zipped project codebase."""
    zip_candidates = [
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "Academic_Research_Paper_Analyzer.zip")),
        r"E:\Academic Research Paper Analyzer\Academic_Research_Paper_Analyzer.zip"
    ]
    for p in zip_candidates:
        if os.path.exists(p):
            return FileResponse(
                path=p,
                filename="Academic_Research_Paper_Analyzer.zip",
                media_type="application/zip"
            )
    raise HTTPException(status_code=404, detail="Project zip archive not found.")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
