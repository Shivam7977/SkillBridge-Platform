import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import Navbar from './components/Navbar';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import AuthModal from './components/AuthModal';
import SavedPapersModal from './components/SavedPapersModal';
import ExportModal from './components/ExportModal';
import { api } from './services/api';
import { firestoreService } from './firebase/firestoreService';
import { storageService } from './firebase/storageService';
import { useAuth } from './context/AuthContext';

export default function App() {
  const { currentUser } = useAuth();
  
  const [currentAnalysis, setCurrentAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState(null);
  const [backendOnline, setBackendOnline] = useState(true);

  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Saved papers state
  const [savedPapers, setSavedPapers] = useState([]);
  const [isSaved, setIsSaved] = useState(false);

  // Check backend health on mount
  useEffect(() => {
    const checkStatus = async () => {
      const res = await api.checkHealth();
      setBackendOnline(!!res);
    };
    checkStatus();
    const interval = setInterval(checkStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch saved papers whenever currentUser changes
  useEffect(() => {
    const fetchSaved = async () => {
      if (currentUser?.uid) {
        const papers = await firestoreService.getUserPapers(currentUser.uid);
        setSavedPapers(papers);
      } else {
        // If not logged in, check anonymous demo list
        const papers = await firestoreService.getUserPapers('guest_demo');
        setSavedPapers(papers);
      }
    };
    fetchSaved();
  }, [currentUser]);

  // Update `isSaved` flag when currentAnalysis or savedPapers change
  useEffect(() => {
    if (currentAnalysis && savedPapers.length > 0) {
      const exists = savedPapers.some(p => p.id === currentAnalysis.id || p.metadata?.title === currentAnalysis.metadata?.title);
      setIsSaved(exists);
    } else {
      setIsSaved(false);
    }
  }, [currentAnalysis, savedPapers]);

  // Fire celebratory confetti on successful paper analysis
  const triggerSuccessCelebration = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {}
  };

  // 1. Analyze Uploaded PDF
  const handleAnalyzeFile = async (file, onProgress) => {
    setError(null);
    setIsAnalyzing(true);
    try {
      const result = await api.analyzePDF(file, onProgress);
      setCurrentAnalysis(result);
      triggerSuccessCelebration();
    } catch (err) {
      console.error("PDF analysis error:", err);
      setError(err.message || "Failed to analyze paper. Please check that the backend is running.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 2. Analyze Pasted Text
  const handleAnalyzeText = async (text, title) => {
    setError(null);
    setIsAnalyzing(true);
    try {
      const result = await api.analyzeText(text, title);
      setCurrentAnalysis(result);
      triggerSuccessCelebration();
    } catch (err) {
      console.error("Text analysis error:", err);
      setError(err.message || "Failed to analyze manuscript text.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 3. Load Sample Paper (Attention Is All You Need)
  const handleLoadSample = async () => {
    setError(null);
    setIsAnalyzing(true);
    try {
      const sample = await api.getSamplePaper();
      setCurrentAnalysis(sample);
      triggerSuccessCelebration();
    } catch (err) {
      console.error("Error loading sample:", err);
      setError("Failed to load sample paper from API.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 4. Save Current Analysis to User Profile
  const handleSaveToProfile = async () => {
    if (!currentAnalysis) return;

    const targetUserId = currentUser?.uid || 'guest_demo';

    try {
      await firestoreService.savePaper(targetUserId, currentAnalysis);
      setIsSaved(true);

      // Refresh saved papers list
      const updated = await firestoreService.getUserPapers(targetUserId);
      setSavedPapers(updated);

      if (!currentUser) {
        // Prompt user to sign in to sync across devices
        setIsAuthOpen(true);
      }
    } catch (err) {
      alert("Failed to save paper to profile: " + err.message);
    }
  };

  // 5. Delete Saved Paper
  const handleDeletePaper = async (paperId) => {
    const targetUserId = currentUser?.uid || 'guest_demo';
    await firestoreService.deletePaper(targetUserId, paperId);
    const updated = await firestoreService.getUserPapers(targetUserId);
    setSavedPapers(updated);
    if (currentAnalysis?.id === paperId) {
      setIsSaved(false);
    }
  };

  // 6. Update Paper Notes
  const handleUpdateNotes = async (paperId, notes) => {
    const targetUserId = currentUser?.uid || 'guest_demo';
    await firestoreService.updateNotes(targetUserId, paperId, notes);
    const updated = await firestoreService.getUserPapers(targetUserId);
    setSavedPapers(updated);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Navigation */}
      <Navbar
        onLoadSample={handleLoadSample}
        onOpenLibrary={() => setIsLibraryOpen(true)}
        savedCount={savedPapers.length}
        onOpenAuth={() => setIsAuthOpen(true)}
        backendOnline={backendOnline}
        onReset={() => {
          setCurrentAnalysis(null);
          setError(null);
        }}
      />

      {/* Main Content View */}
      <main className="flex-1 pb-16">
        {currentAnalysis ? (
          <Dashboard
            analysis={currentAnalysis}
            onReset={() => {
              setCurrentAnalysis(null);
              setError(null);
            }}
            onSaveToProfile={handleSaveToProfile}
            isSaved={isSaved}
            onOpenExport={() => setIsExportOpen(true)}
          />
        ) : (
          <FileUpload
            onAnalyzeFile={handleAnalyzeFile}
            onAnalyzeText={handleAnalyzeText}
            isAnalyzing={isAnalyzing}
            error={error}
            clearError={() => setError(null)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-medium">
            ScholarlyAI Academic Paper Analyzer • Powered by PyMuPDF, FastAPI & React
          </p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Extractive Summarization</span>
            <span>•</span>
            <span>Hypothesis Detection</span>
            <span>•</span>
            <span>Citation Mining</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

      <SavedPapersModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        savedPapers={savedPapers}
        onSelectPaper={(paper) => setCurrentAnalysis(paper)}
        onDeletePaper={handleDeletePaper}
        onUpdateNotes={handleUpdateNotes}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        analysis={currentAnalysis}
      />

    </div>
  );
}
