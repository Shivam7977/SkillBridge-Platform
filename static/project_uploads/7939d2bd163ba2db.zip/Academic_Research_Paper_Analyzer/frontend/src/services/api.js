const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

export const api = {
  // Check backend health
  async checkHealth() {
    try {
      const res = await fetch(`${API_BASE}/api/health`, {
        signal: AbortSignal.timeout(3500)
      });
      if (!res.ok) throw new Error("Health check failed");
      return await res.json();
    } catch (err) {
      console.warn("Backend health check failed:", err.message);
      return null;
    }
  },

  // Fetch sample paper for instant demo
  async getSamplePaper() {
    const res = await fetch(`${API_BASE}/api/sample`);
    if (!res.ok) {
      throw new Error(`Failed to load sample paper: ${res.statusText}`);
    }
    return await res.json();
  },

  // Upload PDF for complete analysis
  async analyzePDF(file, onUploadProgress) {
    const formData = new FormData();
    formData.append("file", file);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `${API_BASE}/api/analyze`);

      if (xhr.upload && onUploadProgress) {
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percent = Math.round((event.loaded / event.total) * 100);
            onUploadProgress(percent);
          }
        };
      }

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const responseData = JSON.parse(xhr.responseText);
            resolve(responseData);
          } catch (err) {
            reject(new Error("Invalid JSON response from server"));
          }
        } else {
          try {
            const errData = JSON.parse(xhr.responseText);
            reject(new Error(errData.detail || "Analysis failed"));
          } catch {
            reject(new Error(`Server error (${xhr.status}): ${xhr.statusText}`));
          }
        }
      };

      xhr.onerror = () => {
        reject(new Error("Network connection error. Please ensure the Python backend is running at http://localhost:8000."));
      };

      xhr.ontimeout = () => {
        reject(new Error("Request timed out during PDF processing."));
      };

      xhr.timeout = 180000; // 3 minute timeout for large papers
      xhr.send(formData);
    });
  },

  // Analyze raw manuscript text
  async analyzeText(text, title = "Manuscript") {
    const res = await fetch(`${API_BASE}/api/analyze-text`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, title })
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || "Failed to analyze manuscript text");
    }

    return await res.json();
  }
};
