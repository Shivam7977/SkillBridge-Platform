import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy, 
  serverTimestamp,
  updateDoc
} from 'firebase/firestore';
import { db, isFirebaseConfigured } from './config';

const LOCAL_PAPERS_PREFIX = 'academic_analyzer_papers_';

export const firestoreService = {
  // Save paper analysis to user's collection
  async savePaper(userId, paperData, pdfStorageUrl = null) {
    if (!userId) throw new Error("User ID is required to save papers");

    const paperId = paperData.id || `paper_${Date.now()}`;
    const payload = {
      ...paperData,
      id: paperId,
      pdfStorageUrl: pdfStorageUrl || null,
      savedAt: new Date().toISOString(),
      userNotes: paperData.userNotes || ""
    };

    if (isFirebaseConfigured && db) {
      const userPaperRef = doc(db, 'users', userId, 'papers', paperId);
      await setDoc(userPaperRef, {
        ...payload,
        updatedAt: serverTimestamp()
      });
      return payload;
    }

    // Local fallback
    const key = `${LOCAL_PAPERS_PREFIX}${userId}`;
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    const filtered = existing.filter(p => p.id !== paperId);
    filtered.unshift(payload);
    localStorage.setItem(key, JSON.stringify(filtered));
    return payload;
  },

  // Get all saved papers for user
  async getUserPapers(userId) {
    if (!userId) return [];

    if (isFirebaseConfigured && db) {
      try {
        const papersRef = collection(db, 'users', userId, 'papers');
        const q = query(papersRef, orderBy('savedAt', 'desc'));
        const snapshot = await getDocs(q);
        const papers = [];
        snapshot.forEach(docSnap => {
          papers.push({ ...docSnap.data(), id: docSnap.id });
        });
        return papers;
      } catch (err) {
        console.warn("Error fetching from Firestore, falling back to local:", err);
      }
    }

    // Local fallback
    const key = `${LOCAL_PAPERS_PREFIX}${userId}`;
    return JSON.parse(localStorage.getItem(key) || '[]');
  },

  // Delete a saved paper
  async deletePaper(userId, paperId) {
    if (!userId || !paperId) return;

    if (isFirebaseConfigured && db) {
      try {
        const paperRef = doc(db, 'users', userId, 'papers', paperId);
        await deleteDoc(paperRef);
      } catch (err) {
        console.warn("Error deleting from Firestore:", err);
      }
    }

    // Local fallback
    const key = `${LOCAL_PAPERS_PREFIX}${userId}`;
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    const updated = existing.filter(p => p.id !== paperId);
    localStorage.setItem(key, JSON.stringify(updated));
  },

  // Update notes on a saved paper
  async updateNotes(userId, paperId, notes) {
    if (!userId || !paperId) return;

    if (isFirebaseConfigured && db) {
      try {
        const paperRef = doc(db, 'users', userId, 'papers', paperId);
        await updateDoc(paperRef, { userNotes: notes });
      } catch (err) {
        console.warn("Error updating notes in Firestore:", err);
      }
    }

    // Local fallback
    const key = `${LOCAL_PAPERS_PREFIX}${userId}`;
    const existing = JSON.parse(localStorage.getItem(key) || '[]');
    const paper = existing.find(p => p.id === paperId);
    if (paper) {
      paper.userNotes = notes;
      localStorage.setItem(key, JSON.stringify(existing));
    }
  }
};
