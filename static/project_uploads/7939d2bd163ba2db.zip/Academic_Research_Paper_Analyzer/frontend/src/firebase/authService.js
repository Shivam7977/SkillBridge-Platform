import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  signOut as fbSignOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import { auth, googleProvider, isFirebaseConfigured } from './config';

const LOCAL_USER_KEY = 'academic_analyzer_demo_user';

export const authService = {
  // Listen for auth state changes
  onAuthChange(callback) {
    if (isFirebaseConfigured && auth) {
      return onAuthStateChanged(auth, callback);
    }
    // Demo mode: check localStorage
    const saved = localStorage.getItem(LOCAL_USER_KEY);
    if (saved) {
      try {
        callback(JSON.parse(saved));
      } catch {
        callback(null);
      }
    } else {
      callback(null);
    }
    return () => {};
  },

  // Sign up with email & password
  async register(email, password, displayName = "") {
    if (isFirebaseConfigured && auth) {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      if (displayName && cred.user) {
        await updateProfile(cred.user, { displayName });
      }
      return cred.user;
    }
    // Demo mode
    const mockUser = {
      uid: `demo_user_${Date.now()}`,
      email,
      displayName: displayName || email.split('@')[0],
      photoURL: null,
      isDemo: true
    };
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  },

  // Sign in with email & password
  async login(email, password) {
    if (isFirebaseConfigured && auth) {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      return cred.user;
    }
    // Demo mode
    const mockUser = {
      uid: `demo_user_${email.replace(/[^a-zA-Z0-9]/g, '_')}`,
      email,
      displayName: email.split('@')[0],
      photoURL: null,
      isDemo: true
    };
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  },

  // Sign in with Google
  async loginWithGoogle() {
    if (isFirebaseConfigured && auth && googleProvider) {
      const result = await signInWithPopup(auth, googleProvider);
      return result.user;
    }
    // Demo fallback for Google
    const mockUser = {
      uid: 'demo_google_researcher',
      email: 'researcher@university.edu',
      displayName: 'Dr. Jane Scholar',
      photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
      isDemo: true
    };
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  },

  // Demo / Guest fast login
  loginAsGuest(role = "Guest Researcher") {
    const mockUser = {
      uid: 'guest_researcher_demo',
      email: 'guest@academic-analyzer.local',
      displayName: role,
      photoURL: null,
      isDemo: true
    };
    localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(mockUser));
    return mockUser;
  },

  // Sign out
  async logout() {
    if (isFirebaseConfigured && auth) {
      await fbSignOut(auth);
    }
    localStorage.removeItem(LOCAL_USER_KEY);
  }
};
