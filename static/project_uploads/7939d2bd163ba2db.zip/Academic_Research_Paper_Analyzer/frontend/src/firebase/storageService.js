import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage, isFirebaseConfigured } from './config';

export const storageService = {
  /**
   * Upload a research paper PDF file to Firebase Storage
   * Returns: downloadURL (string)
   */
  async uploadPaperPDF(file, userId = "anonymous") {
    if (!file) return null;

    if (isFirebaseConfigured && storage) {
      try {
        const timestamp = Date.now();
        const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
        const storageRef = ref(storage, `papers/${userId}/${timestamp}_${safeName}`);
        
        const metadata = {
          contentType: file.type || 'application/pdf',
          customMetadata: {
            originalName: file.name,
            uploadedAt: new Date().toISOString()
          }
        };

        const snapshot = await uploadBytes(storageRef, file, metadata);
        const downloadUrl = await getDownloadURL(snapshot.ref);
        return downloadUrl;
      } catch (err) {
        console.warn("Firebase Storage upload failed, proceeding with local reference:", err);
      }
    }

    // In local demo or offline mode, create an object URL
    try {
      return URL.createObjectURL(file);
    } catch {
      return null;
    }
  }
};
