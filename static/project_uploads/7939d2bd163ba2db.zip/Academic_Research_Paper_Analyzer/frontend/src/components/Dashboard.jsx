import React, { useState } from 'react';
import { 
  FileText, 
  Bookmark, 
  BookmarkCheck, 
  Download, 
  ArrowLeft, 
  Sparkles, 
  Layers, 
  Tag, 
  Quote, 
  Gauge, 
  BookOpen,
  Calendar,
  Clock,
  User,
  ExternalLink,
  Share2
} from 'lucide-react';
import OverviewTab from './OverviewTab';
import SectionsTab from './SectionsTab';
import KeyTermsTab from './KeyTermsTab';
import CitationsTab from './CitationsTab';
import ReadabilityTab from './ReadabilityTab';
import FullTextTab from './FullTextTab';

export default function Dashboard({ 
  analysis, 
  onReset, 
  onSaveToProfile, 
  isSaved, 
  onOpenExport 
}) {
  const [activeTab, setActiveTab] = useState('overview');
  const { metadata, sections, key_terms, citations, readability } = analysis;

  const tabs = [
    { id: 'overview', label: 'Overview & TL;DR', icon: Sparkles },
    { id: 'sections', label: 'Section Breakdown', icon: Layers, badge: `${metadata.extracted_sections_count || 6}` },
    { id: 'keyterms', label: 'Key Terms & Concepts', icon: Tag, badge: `${key_terms?.length || 0}` },
    { id: 'citations', label: 'Citations & Context', icon: Quote, badge: `${citations?.total_citations_found || 0}` },
    { id: 'readability', label: 'Readability & Writing', icon: Gauge, badge: `${readability?.academic_tone_score || 85}` },
    { id: 'fulltext', label: 'Full Text Reader', icon: BookOpen },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-6 sm:p-8 relative overflow-hidden">
        
        {/* Subtle decorative background gradient */}
        <div className="absolute top-0 right-0 w-96 h-40 bg-gradient-to-l from-indigo-50/80 via-blue-50/40 to-transparent pointer-events-none"></div>

        {/* Top actions bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Analyze Another Paper</span>
          </button>

          <div className="flex items-center gap-2">
            {/* Save to Profile button */}
            <button
              onClick={onSaveToProfile}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all shadow-xs ${
                isSaved
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                  : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              {isSaved ? (
                <>
                  <BookmarkCheck className="w-4 h-4 text-emerald-600" />
                  <span>Saved to Profile</span>
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4 text-slate-500" />
                  <span>Save to Profile</span>
                </>
              )}
            </button>

            {/* Export button */}
            <button
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-all shadow-sm shadow-indigo-100"
            >
              <Download className="w-4 h-4" />
              <span>Export Report</span>
            </button>
          </div>
        </div>

        {/* Title & Metadata */}
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-3">
            {metadata.title}
          </h1>

          {/* Authors */}
          {metadata.authors && metadata.authors.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 mb-4">
              <span className="text-xs text-slate-400 mr-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5" />
                Authors:
              </span>
              {metadata.authors.slice(0, 6).map((author, i) => (
                <span 
                  key={i} 
                  className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-medium border border-slate-200"
                >
                  {author}
                </span>
              ))}
              {metadata.authors.length > 6 && (
                <span className="text-xs text-slate-500 font-medium">
                  +{metadata.authors.length - 6} more
                </span>
              )}
            </div>
          )}

          {/* Info Pills */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-xs text-slate-500 pt-3 border-t border-slate-100">
            <span className="flex items-center gap-1 font-mono">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              {metadata.file_name} ({metadata.file_size_kb} KB)
            </span>
            <span>•</span>
            <span className="font-mono">
              <strong>{metadata.pages}</strong> {metadata.pages === 1 ? 'page' : 'pages'}
            </span>
            <span>•</span>
            <span className="font-mono">
              <strong>{metadata.word_count.toLocaleString()}</strong> words
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 font-mono text-indigo-600 font-semibold">
              <Clock className="w-3.5 h-3.5" />
              ~{metadata.estimated_reading_time_min} mins reading time
            </span>
            {metadata.year && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1 font-mono">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  {metadata.year}
                </span>
              </>
            )}
          </div>
        </div>

      </div>

      {/* Interactive Tabs Header */}
      <div className="border-b border-slate-200">
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto pb-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${
                    isActive ? 'bg-indigo-700 text-white' : 'bg-slate-200/80 text-slate-600'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Contents View */}
      <div className="transition-all animate-in fade-in duration-200">
        {activeTab === 'overview' && <OverviewTab analysis={analysis} />}
        {activeTab === 'sections' && <SectionsTab sections={sections} />}
        {activeTab === 'keyterms' && <KeyTermsTab terms={key_terms} />}
        {activeTab === 'citations' && <CitationsTab citationsData={citations} />}
        {activeTab === 'readability' && <ReadabilityTab readability={readability} />}
        {activeTab === 'fulltext' && <FullTextTab sections={sections} rawPreview={analysis.raw_text_preview} />}
      </div>

    </div>
  );
}
