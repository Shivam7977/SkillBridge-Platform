import React, { useState } from 'react';
import { FileText, Search, Copy, Check, Download, Layers } from 'lucide-react';

export default function FullTextTab({ sections, rawPreview }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [copied, setCopied] = useState(false);

  // Combine all sections into complete readable paper text
  const fullManuscript = Object.entries(sections)
    .map(([name, sec]) => `=== ${sec.title || name.toUpperCase()} ===\n\n${sec.text}`)
    .join('\n\n\n');

  const handleCopy = () => {
    navigator.clipboard.writeText(fullManuscript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([fullManuscript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `extracted_paper_manuscript.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search within extracted paper..."
            className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          />
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy All Text</span>
              </>
            )}
          </button>

          <button
            onClick={handleDownloadTxt}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download .txt</span>
          </button>
        </div>

      </div>

      {/* Reader Panel */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="space-y-8 paper-content text-sm sm:text-base leading-relaxed">
          {Object.entries(sections).map(([key, sec]) => {
            const hasMatch = !searchQuery || sec.text.toLowerCase().includes(searchQuery.toLowerCase()) || (sec.title && sec.title.toLowerCase().includes(searchQuery.toLowerCase()));
            if (!hasMatch) return null;

            return (
              <section key={key} id={`section-${key}`} className="pt-2">
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-200">
                  <span className="text-xs font-mono font-bold uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                    {key}
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold text-slate-900 font-sans">
                    {sec.title}
                  </h3>
                </div>

                <div className="text-slate-800 whitespace-pre-line bg-slate-50/50 p-4 rounded-xl border border-slate-100 font-serif">
                  {sec.text}
                </div>
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}
