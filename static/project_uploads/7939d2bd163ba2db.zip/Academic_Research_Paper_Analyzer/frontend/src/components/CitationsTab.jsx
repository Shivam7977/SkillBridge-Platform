import React, { useState } from 'react';
import { 
  Bookmark, 
  Quote, 
  ExternalLink, 
  Search, 
  ListOrdered, 
  BookMarked, 
  Layers, 
  Check, 
  Copy 
} from 'lucide-react';
import MetricCard from './MetricCard';

const INTENT_FILTERS = ["All", "Background / Prior Art", "Methodology / Tool Use", "Comparison / Benchmark", "Foundational Theory"];

export default function CitationsTab({ citationsData }) {
  const [selectedIntent, setSelectedIntent] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSubTab, setActiveSubTab] = useState("contexts"); // 'contexts' or 'bibliography'
  const [copiedBib, setCopiedBib] = useState(false);

  const {
    total_citations_found = 0,
    unique_citation_markers = 0,
    citation_density_per_1000_words = 0,
    citation_style = "Numbered [1]",
    citations = [],
    references = []
  } = citationsData || {};

  const filteredCitations = citations.filter((c) => {
    const matchesIntent = selectedIntent === "All" || c.intent === selectedIntent;
    const matchesSearch = c.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.context.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (c.reference_match && c.reference_match.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesIntent && matchesSearch;
  });

  const filteredReferences = references.filter((r) => 
    r.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCopyBibliography = () => {
    navigator.clipboard.writeText(references.join('\n\n'));
    setCopiedBib(true);
    setTimeout(() => setCopiedBib(false), 2000);
  };

  const getIntentBadgeClass = (intent) => {
    switch (intent) {
      case "Comparison / Benchmark":
        return "bg-rose-50 text-rose-700 border-rose-200";
      case "Methodology / Tool Use":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "Foundational Theory":
        return "bg-purple-50 text-purple-700 border-purple-200";
      case "Discussion / Agreement":
        return "bg-emerald-50 text-emerald-700 border-emerald-200";
      default:
        return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <MetricCard
          icon={Quote}
          title="Total Citations"
          value={total_citations_found}
          subtitle="Instances identified in text"
          color="text-indigo-600"
        />
        <MetricCard
          icon={Bookmark}
          title="Unique References"
          value={unique_citation_markers}
          subtitle="Distinct cited works"
          color="text-purple-600"
        />
        <MetricCard
          icon={Layers}
          title="Citation Density"
          value={`${citation_density_per_1000_words}`}
          subtitle="Citations / 1,000 words"
          color="text-blue-600"
        />
        <MetricCard
          icon={BookMarked}
          title="Citation Style"
          value={citation_style.split(' ')[0]}
          subtitle={citation_style}
          badge="Standard"
          badgeColor="bg-slate-100 text-slate-700"
          color="text-slate-600"
        />
      </div>

      {/* Sub Tabs: Citation Contexts vs Full Bibliography */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab("contexts")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeSubTab === "contexts"
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            Citation Context Explorer ({filteredCitations.length})
          </button>
          <button
            onClick={() => setActiveSubTab("bibliography")}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeSubTab === "bibliography"
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            Parsed Bibliography ({references.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={activeSubTab === "contexts" ? "Search citations or text..." : "Search bibliography..."}
            className="w-full pl-9 pr-4 py-1.5 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          />
        </div>
      </div>

      {/* View 1: Citation Contexts Explorer */}
      {activeSubTab === "contexts" && (
        <div className="space-y-4">
          
          {/* Intent filter pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-400 mr-1 uppercase tracking-wider">Intent:</span>
            {INTENT_FILTERS.map((intent) => (
              <button
                key={intent}
                onClick={() => setSelectedIntent(intent)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  selectedIntent === intent
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {intent}
              </button>
            ))}
          </div>

          {/* Cards List */}
          <div className="space-y-3">
            {filteredCitations.map((item) => (
              <div 
                key={item.id}
                className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5 hover:border-indigo-300 transition-colors"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
                      {item.key}
                    </span>
                    <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md border ${getIntentBadgeClass(item.intent)}`}>
                      {item.intent}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 font-medium">
                    Section: <strong className="text-slate-700">{item.section}</strong>
                  </span>
                </div>

                {/* Context Sentence */}
                <div className="bg-slate-50/70 rounded-xl p-3 border border-slate-100 text-xs sm:text-sm text-slate-800 leading-relaxed font-sans mb-3">
                  <span className="text-slate-400 select-none mr-1.5 font-serif text-base">“</span>
                  {item.context}
                  <span className="text-slate-400 select-none ml-1.5 font-serif text-base">”</span>
                </div>

                {/* Matched Bibliography Entry */}
                {item.reference_match ? (
                  <div className="flex items-start gap-2 text-xs text-slate-600 bg-indigo-50/40 p-2.5 rounded-lg border border-indigo-100">
                    <BookMarked className="w-3.5 h-3.5 text-indigo-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-indigo-900">Referenced Publication:</span>{" "}
                      <span>{item.reference_match}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-400 italic">
                    Referenced work indexed in overall bibliography list below.
                  </div>
                )}
              </div>
            ))}

            {filteredCitations.length === 0 && (
              <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 text-xs">
                No citations matched your filter or search query.
              </div>
            )}
          </div>
        </div>
      )}

      {/* View 2: Full Parsed Bibliography */}
      {activeSubTab === "bibliography" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">Extracted Bibliography / References</h3>
              <p className="text-xs text-slate-500">Found {references.length} bibliographic items</p>
            </div>
            <button
              onClick={handleCopyBibliography}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
            >
              {copiedBib ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600">Copied All</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy References</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-3 font-serif text-xs sm:text-sm text-slate-800 leading-relaxed max-h-[600px] overflow-y-auto pr-2">
            {filteredReferences.map((refEntry, idx) => (
              <div 
                key={idx}
                className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 hover:bg-white hover:border-slate-200 transition-colors"
              >
                {refEntry}
              </div>
            ))}

            {filteredReferences.length === 0 && (
              <div className="text-center py-8 text-slate-400 text-xs font-sans">
                No references found or matched.
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
