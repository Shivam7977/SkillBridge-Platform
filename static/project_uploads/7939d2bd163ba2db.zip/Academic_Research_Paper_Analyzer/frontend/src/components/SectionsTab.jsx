import React, { useState } from 'react';
import { 
  BookOpen, 
  Layers, 
  Clock, 
  FileText, 
  Sparkles, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronRight,
  ListFilter
} from 'lucide-react';

const CANONICAL_KEYS = ["Abstract", "Introduction", "Methodology", "Results", "Conclusion", "References"];

export default function SectionsTab({ sections }) {
  const [selectedSecName, setSelectedSecName] = useState("Abstract");
  const [copied, setCopied] = useState(false);

  const currentSection = sections[selectedSecName] || sections["Abstract"] || {};

  const handleCopy = () => {
    if (currentSection.text) {
      navigator.clipboard.writeText(currentSection.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      {/* Sidebar Section Navigation */}
      <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sticky top-20">
        <div className="flex items-center gap-2 mb-3 pb-3 border-b border-slate-100">
          <Layers className="w-4 h-4 text-indigo-600" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Canonical Sections ({CANONICAL_KEYS.length})
          </h3>
        </div>

        <nav className="space-y-1.5">
          {CANONICAL_KEYS.map((key) => {
            const sec = sections[key];
            const isSelected = selectedSecName === key;
            const wordCount = sec?.word_count || 0;

            return (
              <button
                key={key}
                onClick={() => setSelectedSecName(key)}
                className={`w-full text-left px-3.5 py-3 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center justify-between group ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-white' : 'bg-slate-300 group-hover:bg-indigo-400'}`}></span>
                  <span className="font-semibold">{key}</span>
                </div>
                
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <span className={`text-[11px] px-2 py-0.5 rounded-md font-mono ${
                    isSelected ? 'bg-indigo-700 text-indigo-100' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {wordCount > 0 ? `${wordCount}w` : '0w'}
                  </span>
                  <ChevronRight className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                </div>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Main Section Content Area */}
      <div className="lg:col-span-8 space-y-6">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
          
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-6 border-b border-slate-100 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {currentSection.name || selectedSecName}
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 flex items-center gap-1 font-mono">
                  <Clock className="w-3.5 h-3.5" />
                  {currentSection.reading_time_min || 0.5} min read
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 font-mono">
                  {currentSection.word_count || 0} words
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                {currentSection.title || selectedSecName}
              </h2>
            </div>

            <button
              onClick={handleCopy}
              className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Section</span>
                </>
              )}
            </button>
          </div>

          {/* Section Summary / Key Takeaway Banner */}
          {currentSection.summary && (
            <div className="bg-indigo-50/60 border border-indigo-100 rounded-xl p-4 sm:p-5 mb-6">
              <div className="flex items-center gap-2 mb-2 text-indigo-900 font-bold text-xs uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>Section Distillation & Takeaway</span>
              </div>
              <p className="text-sm text-indigo-950 leading-relaxed font-sans">
                {currentSection.summary}
              </p>
            </div>
          )}

          {/* Key Extracted Sentences */}
          {currentSection.key_sentences && currentSection.key_sentences.length > 0 && (
            <div className="mb-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-indigo-500" />
                <span>Salient Sentences</span>
              </h4>
              <div className="space-y-2">
                {currentSection.key_sentences.map((sent, i) => (
                  <div key={i} className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border-l-3 border-indigo-500">
                    "{sent}"
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Full Extracted Section Text */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              Full Extracted Section Text
            </h4>
            <div className="paper-content text-sm sm:text-base leading-relaxed bg-slate-50/40 p-5 rounded-xl border border-slate-100 whitespace-pre-line max-h-[500px] overflow-y-auto">
              {currentSection.text || "No text available for this section."}
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
