import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  FileText, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  Cpu, 
  Bookmark, 
  Gauge, 
  Quote,
  Loader2
} from 'lucide-react';

const ANALYSIS_STEPS = [
  "Uploading document securely...",
  "Extracting layout and text with PyMuPDF...",
  "Segmenting canonical sections (Abstract, Intro, Method, Results, Conclusion)...",
  "Synthesizing multi-level summaries & key contributions...",
  "Detecting central hypothesis and research questions...",
  "Extracting citations & context explorer...",
  "Evaluating Flesch, Gunning Fog & writing suggestions..."
];

export default function FileUpload({ onAnalyzeFile, onAnalyzeText, isAnalyzing, error, clearError }) {
  const [activeMode, setActiveMode] = useState('pdf'); // 'pdf' or 'text'
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [pastedText, setPastedText] = useState("");
  const [pastedTitle, setPastedTitle] = useState("");
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [uploadPercent, setUploadPercent] = useState(0);
  const fileInputRef = useRef(null);

  // Rotate through simulated progress steps when analyzing
  React.useEffect(() => {
    let interval = null;
    if (isAnalyzing) {
      setCurrentStepIdx(0);
      interval = setInterval(() => {
        setCurrentStepIdx((prev) => (prev < ANALYSIS_STEPS.length - 1 ? prev + 1 : prev));
      }, 1600);
    } else {
      setCurrentStepIdx(0);
      setUploadPercent(0);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isAnalyzing]);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndProcessFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      validateAndProcessFile(e.target.files[0]);
    }
  };

  const validateAndProcessFile = (file) => {
    clearError?.();
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (ext !== '.pdf' && ext !== '.txt') {
      alert("Unsupported file format. Please upload a PDF (.pdf) or text (.txt) file.");
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      alert("File exceeds maximum allowed size of 50 MB.");
      return;
    }
    setSelectedFile(file);
    onAnalyzeFile(file, (pct) => setUploadPercent(pct));
  };

  const handleTextSubmit = (e) => {
    e.preventDefault();
    if (!pastedText.trim() || pastedText.trim().length < 50) {
      alert("Please enter at least 50 characters of academic text or manuscript draft.");
      return;
    }
    onAnalyzeText(pastedText.trim(), pastedTitle.trim() || "Pasted Academic Draft");
  };

  return (
    <div className="max-w-4xl mx-auto my-8 px-4">
      {/* Hero Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/60 text-indigo-700 text-xs font-semibold mb-4">
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI-Powered Research Paper Intelligence</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight mb-4">
          Understand Academic Papers in <span className="bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent">Seconds</span>
        </h1>
        <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
          Upload any scholarly PDF to automatically extract sections, synthesize contributions, detect hypotheses, explore citation contexts, and evaluate readability.
        </p>

        {/* Feature Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mt-6 text-xs text-slate-600">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-xs">
            <Cpu className="w-3.5 h-3.5 text-indigo-600" />
            <span>Section Segmentation</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-xs">
            <Quote className="w-3.5 h-3.5 text-blue-600" />
            <span>Hypothesis Detection</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-xs">
            <Bookmark className="w-3.5 h-3.5 text-purple-600" />
            <span>Citation Contexts</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-slate-200 shadow-xs">
            <Gauge className="w-3.5 h-3.5 text-emerald-600" />
            <span>Flesch & Fog Readability</span>
          </div>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="flex justify-center mb-6">
        <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200 shadow-inner">
          <button
            onClick={() => setActiveMode('pdf')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
              activeMode === 'pdf'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Upload Research PDF
          </button>
          <button
            onClick={() => setActiveMode('text')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
              activeMode === 'text'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Paste Text / Abstract
          </button>
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5 text-rose-600" />
          <div className="flex-1 text-sm">
            <p className="font-semibold">Analysis Failed</p>
            <p className="mt-0.5 text-xs text-rose-700">{error}</p>
          </div>
          <button 
            onClick={clearError}
            className="text-xs text-rose-600 hover:text-rose-900 font-medium"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Container */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-card p-6 sm:p-8">
        
        {/* Analyzing / Loading State */}
        {isAnalyzing ? (
          <div className="py-12 px-4 text-center">
            <div className="inline-flex relative mb-6">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-indigo-600"></span>
              </span>
            </div>

            <h3 className="text-xl font-bold text-slate-900 mb-2">
              Analyzing Academic Paper
            </h3>
            <p className="text-sm text-slate-500 max-w-md mx-auto mb-6">
              Extracting structural elements, computing readability indexes, and distilling key findings...
            </p>

            {/* Current Phase */}
            <div className="max-w-md mx-auto bg-slate-50 border border-slate-200 rounded-xl p-4 text-left">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></span>
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600">
                  Step {currentStepIdx + 1} of {ANALYSIS_STEPS.length}
                </span>
              </div>
              <p className="text-sm font-medium text-slate-800">
                {ANALYSIS_STEPS[currentStepIdx]}
              </p>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 h-1.5 rounded-full mt-3 overflow-hidden">
                <div 
                  className="bg-indigo-600 h-full transition-all duration-500 rounded-full"
                  style={{ width: `${Math.max(15, ((currentStepIdx + 1) / ANALYSIS_STEPS.length) * 100)}%` }}
                ></div>
              </div>
            </div>

            {selectedFile && (
              <p className="text-xs text-slate-400 mt-4 font-mono truncate max-w-sm mx-auto">
                Target: {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
              </p>
            )}
          </div>
        ) : activeMode === 'pdf' ? (
          
          /* PDF Upload Mode */
          <div>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all ${
                isDragging
                  ? 'border-indigo-600 bg-indigo-50/50 scale-[0.99]'
                  : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.txt"
                onChange={handleFileSelect}
                className="hidden"
              />

              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center mb-4 shadow-sm border border-indigo-100 group-hover:scale-105 transition-transform">
                <UploadCloud className="w-8 h-8" />
              </div>

              <h4 className="text-base sm:text-lg font-bold text-slate-900 mb-1">
                Drag and drop your academic paper here
              </h4>
              <p className="text-xs sm:text-sm text-slate-500 mb-4">
                or <span className="text-indigo-600 font-semibold hover:underline">browse files</span> from your computer
              </p>

              <div className="inline-flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-500 text-xs">
                <span>Supports: <strong>PDF</strong>, <strong>TXT</strong></span>
                <span>•</span>
                <span>Max size: <strong>50 MB</strong></span>
              </div>
            </div>

            {/* Quick Helper Notice */}
            <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 pt-4 border-t border-slate-100">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>Fast PyMuPDF extraction with layout retention & multi-column support</span>
              </span>
              <span className="text-slate-400">Works with arXiv, IEEE, ACM, Nature, Science papers</span>
            </div>
          </div>

        ) : (

          /* Manual Text / Abstract Mode */
          <form onSubmit={handleTextSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Paper Title or Topic (Optional)
                </label>
                <input
                  type="text"
                  value={pastedTitle}
                  onChange={(e) => setPastedTitle(e.target.value)}
                  placeholder="e.g. Scaling Laws for Neural Language Models"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Manuscript Text, Abstract, or Excerpt
                </label>
                <textarea
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  rows={10}
                  placeholder="Paste the full paper text or sections (Abstract, Introduction, Methodology, Results, Conclusion, References)..."
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 leading-relaxed"
                ></textarea>
                <div className="flex justify-between items-center mt-1 text-xs text-slate-400">
                  <span>Minimum 50 characters</span>
                  <span>{pastedText.length} characters</span>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={!pastedText.trim()}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md shadow-indigo-100"
                >
                  <span>Analyze Manuscript</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </form>

        )}

      </div>
    </div>
  );
}
