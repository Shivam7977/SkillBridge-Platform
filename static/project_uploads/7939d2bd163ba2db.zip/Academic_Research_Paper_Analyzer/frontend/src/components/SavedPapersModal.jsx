import React, { useState } from 'react';
import { 
  X, 
  Bookmark, 
  Trash2, 
  ArrowRight, 
  Clock, 
  FileText, 
  Search, 
  BookOpen, 
  Edit3, 
  Save, 
  Check,
  Calendar
} from 'lucide-react';

export default function SavedPapersModal({ 
  isOpen, 
  onClose, 
  savedPapers = [], 
  onSelectPaper, 
  onDeletePaper, 
  onUpdateNotes 
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [tempNotes, setTempNotes] = useState("");

  if (!isOpen) return null;

  const filtered = savedPapers.filter((p) => {
    const titleMatch = p.metadata?.title?.toLowerCase().includes(searchQuery.toLowerCase());
    const notesMatch = p.userNotes?.toLowerCase().includes(searchQuery.toLowerCase());
    return titleMatch || notesMatch;
  });

  const handleStartEdit = (p) => {
    setEditingId(p.id);
    setTempNotes(p.userNotes || "");
  };

  const handleSaveNotes = async (id) => {
    await onUpdateNotes(id, tempNotes);
    setEditingId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div 
        className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
              <Bookmark className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">My Saved Research Papers</h3>
              <p className="text-xs text-slate-500">
                {savedPapers.length} analysis reports saved to your profile
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search saved papers by title, authors, or your custom notes..."
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 bg-white"
            />
          </div>
        </div>

        {/* Papers List */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {filtered.map((paper) => (
            <div 
              key={paper.id}
              className="bg-white rounded-xl border border-slate-200 p-5 hover:border-indigo-300 hover:shadow-xs transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1">
                    <span className="flex items-center gap-1 font-mono">
                      <Calendar className="w-3 h-3" />
                      {paper.savedAt ? new Date(paper.savedAt).toLocaleDateString() : 'Recent'}
                    </span>
                    <span>•</span>
                    <span className="font-mono">{paper.metadata?.pages || 1} pages</span>
                    <span>•</span>
                    <span className="font-mono">{paper.metadata?.word_count?.toLocaleString()} words</span>
                  </div>

                  <h4 className="text-base font-bold text-slate-900 leading-snug">
                    {paper.metadata?.title}
                  </h4>

                  {paper.metadata?.authors && paper.metadata.authors.length > 0 && (
                    <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                      {paper.metadata.authors.join(", ")}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-start">
                  <button
                    onClick={() => {
                      onSelectPaper(paper);
                      onClose();
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-xs"
                  >
                    <span>View Analysis</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onDeletePaper(paper.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Delete saved paper"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* User Notes Section */}
              <div className="pt-2 border-t border-slate-100 text-xs">
                {editingId === paper.id ? (
                  <div className="space-y-2 mt-2">
                    <textarea
                      value={tempNotes}
                      onChange={(e) => setTempNotes(e.target.value)}
                      placeholder="Add personal notes, critique, or research takeaways for this paper..."
                      rows={2}
                      className="w-full p-2.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    ></textarea>
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setEditingId(null)}
                        className="px-2.5 py-1 rounded text-xs text-slate-600 hover:bg-slate-100"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleSaveNotes(paper.id)}
                        className="px-3 py-1 rounded bg-indigo-600 text-white font-medium text-xs hover:bg-indigo-700 flex items-center gap-1"
                      >
                        <Save className="w-3 h-3" />
                        <span>Save Notes</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-2 mt-1">
                    <div className="text-slate-600 italic">
                      {paper.userNotes ? (
                        <span><strong className="not-italic text-slate-700 font-semibold">Note:</strong> {paper.userNotes}</span>
                      ) : (
                        <span className="text-slate-400">No personal notes added yet.</span>
                      )}
                    </div>
                    <button
                      onClick={() => handleStartEdit(paper)}
                      className="text-[11px] text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1 flex-shrink-0"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>{paper.userNotes ? "Edit Note" : "Add Note"}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="font-semibold text-slate-700">No saved papers found</p>
              <p className="text-xs text-slate-400 mt-1">
                Upload or analyze a paper, then click "Save to Profile" to store it here.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
