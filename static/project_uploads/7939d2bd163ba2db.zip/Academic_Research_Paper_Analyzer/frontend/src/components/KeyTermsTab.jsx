import React, { useState } from 'react';
import { 
  Tag, 
  Search, 
  Layers, 
  Hash, 
  Compass, 
  Cpu, 
  BarChart, 
  Database,
  Quote
} from 'lucide-react';

const CATEGORIES = ["All", "Method/Algorithm", "Key Concept", "Metric/Evaluation", "Dataset/Benchmark", "Domain Term"];

export default function KeyTermsTab({ terms = [] }) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedTerm, setExpandedTerm] = useState(null);

  const filteredTerms = terms.filter((item) => {
    const matchesCategory = selectedCategory === "All" || item.category === selectedCategory;
    const matchesSearch = item.term.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (item.example_context && item.example_context.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const getCategoryBadgeClass = (category) => {
    switch (category) {
      case "Method/Algorithm":
        return "bg-purple-50 text-purple-700 border-purple-200";
      case "Metric/Evaluation":
        return "bg-emerald-50 text-emerald-700 border-emerald-200";
      case "Dataset/Benchmark":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "Key Concept":
        return "bg-indigo-50 text-indigo-700 border-indigo-200";
      default:
        return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Search & Filter Header */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search key terms or context..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
          />
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

      </div>

      {/* Terms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTerms.map((item, idx) => {
          const isExpanded = expandedTerm === idx;
          const relevancePct = Math.round(item.relevance_score * 100);

          return (
            <div
              key={idx}
              onClick={() => setExpandedTerm(isExpanded ? null : idx)}
              className={`bg-white rounded-xl border p-5 transition-all cursor-pointer hover:shadow-md ${
                isExpanded ? 'border-indigo-500 ring-2 ring-indigo-500/10 shadow-sm' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md border ${getCategoryBadgeClass(item.category)}`}>
                  {item.category}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                  <Hash className="w-3 h-3" />
                  {item.frequency}x
                </span>
              </div>

              <h4 className="text-base font-bold text-slate-900 mb-2 truncate">
                {item.term}
              </h4>

              {/* Relevance Score Bar */}
              <div className="space-y-1 mb-3">
                <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                  <span>Relevance</span>
                  <span className="font-mono">{relevancePct}%</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all"
                    style={{ width: `${relevancePct}%` }}
                  ></div>
                </div>
              </div>

              {/* Example Context / Contextual Usage */}
              {item.example_context && (
                <div className="pt-2 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1">
                    <Quote className="w-3 h-3 text-indigo-500" />
                    <span>In-Paper Context</span>
                  </div>
                  <p className={`text-slate-600 leading-relaxed font-sans ${isExpanded ? '' : 'line-clamp-2'}`}>
                    "{item.example_context}"
                  </p>
                  {!isExpanded && item.example_context.length > 90 && (
                    <span className="text-[11px] text-indigo-600 font-medium mt-1 inline-block">
                      Click to expand context
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filteredTerms.length === 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <Tag className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h4 className="text-base font-bold text-slate-700">No matching terms found</h4>
          <p className="text-xs text-slate-500 mt-1">Try changing your search query or selecting a different category filter.</p>
        </div>
      )}

    </div>
  );
}
