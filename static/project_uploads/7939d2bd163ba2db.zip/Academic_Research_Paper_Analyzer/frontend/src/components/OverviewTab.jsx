import React, { useState } from 'react';
import { 
  Lightbulb, 
  HelpCircle, 
  CheckCircle2, 
  Target, 
  AlertTriangle, 
  Quote, 
  Copy, 
  Check, 
  Award,
  Sparkles,
  BookOpen,
  Clock,
  FileText,
  BarChart2
} from 'lucide-react';
import MetricCard from './MetricCard';

export default function OverviewTab({ analysis }) {
  const [copiedSummary, setCopiedSummary] = useState(false);
  const { metadata, executive_summary, key_contributions, hypothesis, readability, citations } = analysis;

  const handleCopySummary = () => {
    navigator.clipboard.writeText(executive_summary);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Quick Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          icon={Clock}
          title="Est. Reading Time"
          value={`${metadata.estimated_reading_time_min}m`}
          subtitle={`Based on ${metadata.word_count.toLocaleString()} words`}
          badge={`${metadata.pages} Pages`}
          badgeColor="bg-blue-100 text-blue-700"
          color="text-blue-600"
        />
        <MetricCard
          icon={Award}
          title="Academic Tone"
          value={`${readability.academic_tone_score}/100`}
          subtitle="Vocabulary & syntax density"
          badge={readability.academic_tone_score >= 80 ? "Scholarly" : "Standard"}
          badgeColor="bg-emerald-100 text-emerald-700"
          color="text-emerald-600"
        />
        <MetricCard
          icon={BarChart2}
          title="Reading Grade"
          value={readability.flesch_kincaid_grade.grade_level}
          subtitle={`Fog: ${readability.gunning_fog.grade_level}`}
          badge={readability.overall_reading_level.split('/')[0]}
          badgeColor="bg-purple-100 text-purple-700"
          color="text-purple-600"
        />
        <MetricCard
          icon={Quote}
          title="Citation Density"
          value={`${citations.citation_density_per_1000_words}`}
          subtitle="Citations per 1,000 words"
          badge={`${citations.total_citations_found} Found`}
          badgeColor="bg-amber-100 text-amber-700"
          color="text-amber-600"
        />
      </div>

      {/* Executive Summary Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50/50 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Executive Summary / TL;DR</h3>
              <p className="text-xs text-slate-500">Synthesized from Abstract, Contributions, and Findings</p>
            </div>
          </div>
          <button
            onClick={handleCopySummary}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors"
          >
            {copiedSummary ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-600">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>

        <p className="text-sm sm:text-base text-slate-700 leading-relaxed font-sans bg-slate-50/60 p-4 rounded-xl border border-slate-100">
          {executive_summary}
        </p>
      </div>

      {/* Hypothesis & Research Questions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Main Hypothesis Card */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Primary Hypothesis</h3>
                  <p className="text-xs text-slate-500">Core theoretical thesis or premise</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                {(hypothesis.hypothesis_confidence * 100).toFixed(0)}% Confidence
              </span>
            </div>

            <div className="bg-amber-50/40 border border-amber-200/60 rounded-xl p-4 my-2">
              <p className="text-sm text-amber-950 font-medium leading-relaxed italic">
                "{hypothesis.primary_hypothesis || "No explicit hypothesis sentence detected; see core objectives below."}"
              </p>
            </div>

            {/* Problem Statement */}
            {hypothesis.problem_statement && (
              <div className="mt-4 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-slate-500" />
                  <span>Problem Statement & Bottleneck</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {hypothesis.problem_statement}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Research Questions & Objectives Card */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Central Research Questions</h3>
                <p className="text-xs text-slate-500">Core inquiries addressed by the authors</p>
              </div>
            </div>

            {hypothesis.research_questions && hypothesis.research_questions.length > 0 ? (
              <ul className="space-y-2.5">
                {hypothesis.research_questions.map((rq, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold text-[10px] flex items-center justify-center flex-shrink-0 mt-0.5">
                      Q{idx + 1}
                    </span>
                    <span className="flex-1 font-medium">{rq}</span>
                  </li>
                ))}
              </ul>
            ) : hypothesis.core_objectives && hypothesis.core_objectives.length > 0 ? (
              <ul className="space-y-2.5">
                {hypothesis.core_objectives.map((obj, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <Target className="w-4 h-4 text-indigo-600 flex-shrink-0 mt-0.5" />
                    <span className="flex-1">{obj}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-slate-500 italic">
                Research questions are implicitly embedded within the methodology and experimental aims.
              </p>
            )}

            {/* Core Objectives */}
            {hypothesis.core_objectives && hypothesis.core_objectives.length > 0 && hypothesis.research_questions.length > 0 && (
              <div className="mt-4 pt-4 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                  Primary Objectives
                </span>
                <div className="space-y-1.5">
                  {hypothesis.core_objectives.slice(0, 2).map((obj, i) => (
                    <div key={i} className="text-xs text-slate-600 flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                      <span>{obj}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Key Contributions Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center gap-2.5 mb-4">
          <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">Key Contributions & Novelties</h3>
            <p className="text-xs text-slate-500">Explicit claims made by the authors</p>
          </div>
        </div>

        {key_contributions && key_contributions.length > 0 ? (
          <div className="space-y-3">
            {key_contributions.map((contribution, idx) => (
              <div 
                key={idx}
                className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50/70 border border-slate-200/60 hover:bg-white hover:shadow-xs transition-all"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">
                  {idx + 1}
                </div>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed flex-1">
                  {contribution}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-500 italic">
            No isolated contribution list was explicitly labeled; see executive summary above.
          </p>
        )}
      </div>

    </div>
  );
}
