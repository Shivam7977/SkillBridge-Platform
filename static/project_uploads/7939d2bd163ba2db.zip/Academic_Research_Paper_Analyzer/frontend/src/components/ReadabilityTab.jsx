import React from 'react';
import { 
  Gauge, 
  Lightbulb, 
  CheckCircle, 
  AlertCircle, 
  Award, 
  BarChart3, 
  Sliders, 
  Sparkles,
  BookOpen,
  HelpCircle
} from 'lucide-react';
import MetricCard from './MetricCard';

export default function ReadabilityTab({ readability }) {
  const {
    flesch_reading_ease,
    flesch_kincaid_grade,
    gunning_fog,
    coleman_liau,
    automated_readability_index,
    smog_index,
    average_sentence_length,
    average_syllables_per_word,
    complex_words_percentage,
    lexical_diversity_ttr,
    academic_tone_score,
    overall_reading_level,
    writing_suggestions = []
  } = readability;

  // Determine Flesch meter color
  const freScore = flesch_reading_ease.score;
  const getFreColor = (score) => {
    if (score >= 60) return "text-emerald-600 bg-emerald-50 border-emerald-200";
    if (score >= 40) return "text-blue-600 bg-blue-50 border-blue-200";
    if (score >= 25) return "text-amber-600 bg-amber-50 border-amber-200";
    return "text-purple-600 bg-purple-50 border-purple-200";
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Overall Scholarly Reading Level */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
              <Award className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Composite Readability Evaluation
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {overall_reading_level}
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl">
            Calculated across {flesch_kincaid_grade.grade_level} and Gunning Fog {gunning_fog.score}. The paper exhibits characteristic academic density appropriate for scholarly peer review.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 sm:p-5 text-center min-w-[200px] flex-shrink-0">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
            Academic Tone Score
          </span>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-3xl font-black text-indigo-600 font-mono">{academic_tone_score}</span>
            <span className="text-sm font-semibold text-slate-400">/100</span>
          </div>
          <span className="inline-block mt-2 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
            {academic_tone_score >= 80 ? "Rigorous Scholarly" : "Accessible Academic"}
          </span>
        </div>
      </div>

      {/* Primary Readability Index Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        
        {/* Flesch Reading Ease */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Flesch Reading Ease</span>
            <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getFreColor(freScore)}`}>
              {freScore}/100
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mb-1">
            {flesch_reading_ease.interpretation}
          </div>
          <p className="text-xs text-slate-500 mb-4">{flesch_reading_ease.benchmark}</p>
          
          {/* Progress gauge */}
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 h-full rounded-full transition-all"
              style={{ width: `${Math.min(100, Math.max(10, freScore))}%` }}
            ></div>
          </div>
        </div>

        {/* Flesch-Kincaid Grade Level */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Flesch-Kincaid Grade</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
              {flesch_kincaid_grade.grade_level}
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mb-1 font-mono">
            Grade {flesch_kincaid_grade.score}
          </div>
          <p className="text-xs text-slate-500 mb-2">{flesch_kincaid_grade.interpretation}</p>
          <span className="text-[11px] font-mono text-slate-400 bg-slate-50 px-2 py-0.5 rounded block">
            {flesch_kincaid_grade.benchmark}
          </span>
        </div>

        {/* Gunning Fog Index */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Gunning Fog Index</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
              Index {gunning_fog.score}
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mb-1 font-mono">
            {gunning_fog.grade_level}
          </div>
          <p className="text-xs text-slate-500 mb-2">{gunning_fog.interpretation}</p>
          <span className="text-[11px] font-mono text-slate-400 bg-slate-50 px-2 py-0.5 rounded block">
            {gunning_fog.benchmark}
          </span>
        </div>

        {/* Coleman-Liau Index */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Coleman-Liau Index</span>
            <span className="text-xs font-mono font-bold text-slate-700">{coleman_liau.score}</span>
          </div>
          <div className="text-lg font-bold text-slate-800 mb-1">{coleman_liau.grade_level}</div>
          <p className="text-xs text-slate-500">{coleman_liau.interpretation}</p>
        </div>

        {/* Automated Readability Index (ARI) */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Automated Readability (ARI)</span>
            <span className="text-xs font-mono font-bold text-slate-700">{automated_readability_index.score}</span>
          </div>
          <div className="text-lg font-bold text-slate-800 mb-1">{automated_readability_index.grade_level}</div>
          <p className="text-xs text-slate-500">{automated_readability_index.interpretation}</p>
        </div>

        {/* SMOG Index */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">SMOG Index</span>
            <span className="text-xs font-mono font-bold text-slate-700">{smog_index.score}</span>
          </div>
          <div className="text-lg font-bold text-slate-800 mb-1">{smog_index.grade_level}</div>
          <p className="text-xs text-slate-500">{smog_index.interpretation}</p>
        </div>

      </div>

      {/* Stylistic Metrics Breakdown Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 mb-5 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-indigo-600" />
          <span>Stylistic & Vocabulary Metrics Breakdown</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-xs text-slate-500 font-medium block mb-1">Avg Sentence Length</span>
            <span className="text-xl font-bold text-slate-900 font-mono">{average_sentence_length}</span>
            <span className="text-[11px] text-slate-400 block mt-0.5">words / sentence</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-xs text-slate-500 font-medium block mb-1">Syllables / Word</span>
            <span className="text-xl font-bold text-slate-900 font-mono">{average_syllables_per_word}</span>
            <span className="text-[11px] text-slate-400 block mt-0.5">syllables / token</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-xs text-slate-500 font-medium block mb-1">Complex Words (&ge;3 syl)</span>
            <span className="text-xl font-bold text-slate-900 font-mono">{complex_words_percentage}%</span>
            <span className="text-[11px] text-slate-400 block mt-0.5">polysyllabic density</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
            <span className="text-xs text-slate-500 font-medium block mb-1">Lexical Diversity (TTR)</span>
            <span className="text-xl font-bold text-slate-900 font-mono">{lexical_diversity_ttr}</span>
            <span className="text-[11px] text-slate-400 block mt-0.5">unique / total words</span>
          </div>
        </div>
      </div>

      {/* Actionable Writing Suggestions */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="flex items-center gap-2.5 mb-5">
          <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
            <Lightbulb className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Writing & Readability Suggestions
            </h3>
            <p className="text-xs text-slate-500">
              Automated feedback tailored to peer-reviewed academic dissemination
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {writing_suggestions.map((suggestion, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50/40 border border-amber-200/60"
            >
              <div className="w-5 h-5 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5">
                {idx + 1}
              </div>
              <p className="text-xs sm:text-sm text-slate-800 leading-relaxed flex-1">
                {suggestion}
              </p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
