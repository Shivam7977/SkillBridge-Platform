# ScholarlyAI — Academic Research Paper Analyzer

> A high-performance web application designed to accelerate literature review and research synthesis. Upload any scholarly paper in PDF format to automatically segment canonical sections, synthesize multi-tiered summaries, detect core hypotheses and research questions, explore citation contexts, and evaluate readability metrics.

---

## 🌟 Key Features

### 📄 PDF Extraction & Section Segmentation
- **PyMuPDF (`fitz`) Layout Engine:** Extracts high-fidelity text with font size and style analysis to segment multi-column academic layouts.
- **Canonical Section Classification:** Automatically detects and extracts:
  - **Abstract** (distillation & summary)
  - **Introduction** (background & motivation)
  - **Methodology** (materials, methods, architectures, and algorithms)
  - **Results** (empirical evaluations, benchmarks, and ablation studies)
  - **Discussion / Conclusion** (limitations, takeaways, and future work)
  - **References / Bibliography** (individual publication entries)

### 🧠 Advanced NLP Analysis
- **Executive Summarization:** Multi-level summaries combining an overarching Executive TL;DR, key contributions, and section-by-section takeaways.
- **Key Terms & Concept Mining:** Extracts unigrams, bigrams, and trigrams with TF-IDF weighting, categorized into *Methods*, *Metrics*, *Concepts*, and *Datasets*, paired with contextual example sentences.
- **Hypothesis & Research Question Detection:** Linguistic pattern matcher that identifies:
  - Primary theoretical hypothesis with confidence scoring
  - Research questions ($Q_1, Q_2, \dots$)
  - Core research objectives
  - Problem statements and methodological bottlenecks
- **Citation Context Explorer:**
  - Extracts both bracketed numbered citations (`[1]`, `[1, 2]`) and author-year citations (`(Vaswani et al., 2017)`).
  - Captures the exact enclosing context sentence.
  - Classifies citation intent (*Foundational Theory*, *Methodology/Tool Use*, *Comparison/Benchmark*, *Background*).
  - Matches citations to parsed bibliography entries in the references list.
- **Readability & Writing Evaluation:**
  - Standard scientific indices: **Flesch Reading Ease**, **Flesch-Kincaid Grade Level**, **Gunning Fog**, **Coleman-Liau**, **ARI**, and **SMOG Index**.
  - Stylistic metrics: average sentence length, syllable density, polysyllabic complex word percentage, lexical diversity (Type-Token Ratio), and an **Academic Tone Score** ($0-100$).
  - Actionable writing improvement suggestions.

### 💻 User-Friendly Dashboard & Profile Persistence
- **Interactive Multi-Tab Dashboard:** Clean, responsive UI built with React and Tailwind CSS.
- **Firebase Authentication:** Sign up, log in, or sign in with Google (with instant Guest / Demo mode).
- **Firebase Firestore:** Save paper analyses, reading history, and custom annotations to user profiles.
- **Firebase Storage:** Securely upload and store original research PDFs.
- **Export Capabilities:** Download comprehensive reports in Markdown (`.md`), structured JSON (`.json`), or browser Print/PDF layout.
- **Instant Sample Paper:** Includes a 1-click preview of *"Attention Is All You Need"* (Vaswani et al.) for instantaneous testing without uploading files.

---

## 🏗️ System Architecture

```
Academic Research Paper Analyzer/
├── backend/                  # Python FastAPI Backend
│   ├── app/
│   │   ├── config.py         # Configuration & CORS settings
│   │   ├── main.py           # FastAPI endpoints & pipeline orchestration
│   │   ├── models/
│   │   │   └── schemas.py    # Pydantic data models & response contracts
│   │   └── services/
│   │       ├── pdf_extractor.py        # PyMuPDF & layout parsing
│   │       ├── section_parser.py       # Canonical section classifier
│   │       ├── summarizer.py           # TextRank & contribution mining
│   │       ├── hypothesis_detector.py  # Hypothesis & research question NLP
│   │       ├── citation_analyzer.py    # Citation extractor & reference linker
│   │       ├── readability_analyzer.py # Readability formulas & suggestions
│   │       ├── keyword_extractor.py    # N-gram & technical concept mining
│   │       └── sample_paper.py         # Built-in sample paper dataset
│   ├── requirements.txt
│   ├── Dockerfile            # Production Docker image (Google Cloud Run)
│   └── .env.example
├── frontend/                 # React (Vite) + Tailwind CSS Frontend
│   ├── src/
│   │   ├── components/       # Dashboard, Navbar, Tabs, Modals
│   │   ├── context/          # AuthContext (Firebase & Demo modes)
│   │   ├── firebase/         # Firebase Auth, Firestore, and Storage clients
│   │   ├── services/         # API client for FastAPI backend
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── package.json
│   ├── tailwind.config.js
│   └── .env.example
├── firebase.json             # Firebase Hosting configuration
├── firestore.rules           # Firestore security rules
├── storage.rules             # Firebase Storage security rules
├── docker-compose.yml        # Docker compose configuration
└── README.md
```

---

## 🚀 Quickstart Guide

### 1. Prerequisites
- **Python 3.10+**
- **Node.js 18+** and **npm**
- *(Optional)* **Docker** & **Firebase CLI**

---

### 2. Backend Setup (FastAPI)

1. Open a terminal in the project root:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment:
   ```bash
   # Windows (PowerShell)
   python -m venv venv
   .\venv\Scripts\Activate.ps1

   # macOS / Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Pre-download required NLTK tokenizers (runs automatically on first run, or run manually):
   ```bash
   python -c "import nltk; nltk.download('punkt', quiet=True); nltk.download('punkt_tab', quiet=True); nltk.download('stopwords', quiet=True)"
   ```

5. Start the FastAPI development server:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

   The backend is now live at `http://localhost:8000`.  
   Interactive Swagger API documentation is available at `http://localhost:8000/docs`.

---

### 3. Frontend Setup (React + Vite)

1. Open a new terminal in the `frontend` directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   *(Note: The app will run out of the box in Local/Demo mode with full persistence even without entering Firebase credentials!)*

4. Start the frontend development server:
   ```bash
   npm run dev
   ```

5. Open your browser at:
   ```
   http://localhost:5173
   ```

---

## 🐳 Running with Docker Compose

To spin up both backend and frontend simultaneously with Docker:

```bash
docker compose up --build
```
- Frontend: `http://localhost:5173`
- Backend API: `http://localhost:8000`

---

## 🔥 Firebase Setup Guide

The application comes pre-configured with **zero-friction fallback**: if you do not have Firebase keys, the app automatically switches to **Offline / Demo Mode** using local browser storage.

To connect live Firebase services:

### 1. Create a Firebase Project
1. Visit the [Firebase Console](https://console.firebase.google.com/) and click **Add Project**.
2. Enable **Authentication**:
   - Go to *Build > Authentication > Sign-in method*.
   - Enable **Email/Password** and **Google**.
3. Enable **Cloud Firestore**:
   - Go to *Build > Firestore Database > Create Database*.
   - Start in Test mode or apply the provided `firestore.rules`.
4. Enable **Cloud Storage**:
   - Go to *Build > Storage > Get Started*.
   - Apply the provided `storage.rules`.

### 2. Add Web App Credentials
1. In Firebase Console, go to **Project Settings > General > Your apps**.
2. Select the Web icon (`</>`) to register a web application.
3. Copy the configuration values into `frontend/.env`:
   ```env
   VITE_API_URL=http://localhost:8000
   VITE_FIREBASE_API_KEY=AIzaSy...
   VITE_FIREBASE_AUTH_DOMAIN=your-app.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-app
   VITE_FIREBASE_STORAGE_BUCKET=your-app.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
   VITE_FIREBASE_APP_ID=1:123456789:web:abcdef
   ```

---

## ☁️ Production Deployment

### 1. Deploying Backend to Google Cloud Run

Google Cloud Run provides serverless, auto-scaling deployment for the Python FastAPI container.

1. Install and authenticate the [Google Cloud CLI](https://cloud.google.com/sdk/docs/install):
   ```bash
   gcloud auth login
   gcloud config set project YOUR_GCP_PROJECT_ID
   ```

2. Build and submit container image:
   ```bash
   gcloud builds submit --tag gcr.io/YOUR_GCP_PROJECT_ID/paper-analyzer-backend backend/
   ```

3. Deploy to Cloud Run:
   ```bash
   gcloud run deploy paper-analyzer-backend \
     --image gcr.io/YOUR_GCP_PROJECT_ID/paper-analyzer-backend \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated \
     --memory 2Gi \
     --cpu 2
   ```

4. Note down the returned Cloud Run Service URL (e.g., `https://paper-analyzer-backend-xyz.a.run.app`).

---

### 2. Deploying Frontend to Firebase Hosting

1. Update `frontend/.env` with your Cloud Run backend URL:
   ```env
   VITE_API_URL=https://paper-analyzer-backend-xyz.a.run.app
   ```

2. Build the production React assets:
   ```bash
   cd frontend
   npm run build
   cd ..
   ```

3. Deploy to Firebase Hosting:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase deploy --only hosting,firestore:rules,storage:rules
   ```

---

## 📡 API Endpoint Reference

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/analyze` | Upload a PDF (`multipart/form-data`) for end-to-end NLP and structural analysis. |
| `POST` | `/api/analyze-text` | Submit raw academic text or manuscript drafts as JSON (`{ "text": "...", "title": "..." }`). |
| `GET` | `/api/sample` | Instant retrieval of pre-analyzed *"Attention Is All You Need"* paper for demonstrations. |
| `GET` | `/api/health` | Service health status and supported features check. |
| `GET` | `/docs` | Interactive Swagger / OpenAPI documentation UI. |

---

## 🔒 Security & Data Privacy

- **File Cleanup:** Uploaded files are processed in-memory via temporary streams and are not stored indefinitely on backend disks.
- **Client-Side Storage Isolation:** Firestore security rules ensure researchers can only read and write their own documents matching `request.auth.uid == userId`.
- **Storage Limits:** Maximum upload file size is capped at 50 MB to prevent abuse.

---

## 📄 License
MIT License. Created for researchers, students, and academic peer review workflows.
