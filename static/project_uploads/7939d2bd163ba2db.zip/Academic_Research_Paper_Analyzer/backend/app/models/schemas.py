from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class PaperMetadata(BaseModel):
    title: str
    authors: List[str] = []
    year: Optional[str] = None
    pages: int = 1
    word_count: int = 0
    char_count: int = 0
    estimated_reading_time_min: float = 0.0
    file_name: str
    file_size_kb: float = 0.0
    extracted_sections_count: int = 0

class SectionData(BaseModel):
    name: str
    title: str
    text: str
    word_count: int = 0
    summary: str = ""
    key_sentences: List[str] = []
    reading_time_min: float = 0.0

class HypothesisCandidate(BaseModel):
    sentence: str
    score: float
    cue_type: str
    context: Optional[str] = None

class HypothesisAnalysis(BaseModel):
    primary_hypothesis: Optional[str] = None
    hypothesis_confidence: float = 0.0
    hypothesis_candidates: List[HypothesisCandidate] = []
    research_questions: List[str] = []
    core_objectives: List[str] = []
    problem_statement: Optional[str] = None
    methodological_claims: List[str] = []

class CitationItem(BaseModel):
    id: str
    key: str
    context: str
    section: str = "General"
    intent: str = "Background"
    reference_match: Optional[str] = None

class CitationAnalysis(BaseModel):
    total_citations_found: int = 0
    unique_citation_markers: int = 0
    citation_density_per_1000_words: float = 0.0
    citations: List[CitationItem] = []
    references: List[str] = []
    citation_style: str = "Numbered [1]"

class ReadabilityMetric(BaseModel):
    score: float
    grade_level: str
    interpretation: str
    benchmark: str

class ReadabilityAnalysis(BaseModel):
    flesch_reading_ease: ReadabilityMetric
    flesch_kincaid_grade: ReadabilityMetric
    gunning_fog: ReadabilityMetric
    coleman_liau: ReadabilityMetric
    automated_readability_index: ReadabilityMetric
    smog_index: ReadabilityMetric
    average_sentence_length: float
    average_syllables_per_word: float
    complex_words_percentage: float
    lexical_diversity_ttr: float
    academic_tone_score: float
    overall_reading_level: str
    writing_suggestions: List[str] = []

class KeyTerm(BaseModel):
    term: str
    frequency: int
    relevance_score: float
    category: str = "Concept/Theory"
    example_context: Optional[str] = None

class PaperAnalysisResponse(BaseModel):
    id: str
    timestamp: str
    metadata: PaperMetadata
    executive_summary: str
    key_contributions: List[str] = []
    sections: Dict[str, SectionData]
    hypothesis: HypothesisAnalysis
    citations: CitationAnalysis
    readability: ReadabilityAnalysis
    key_terms: List[KeyTerm] = []
    raw_text_preview: str = ""

class TextAnalysisRequest(BaseModel):
    text: str
    title: Optional[str] = "Pasted Academic Text"
    file_name: Optional[str] = "manual_input.txt"
