import re
import io
from typing import Tuple, List, Dict, Any, Optional
import pymupdf
import pypdf

class PDFExtractor:
    @staticmethod
    def clean_text(text: str) -> str:
        """Fix hyphenations across line breaks, normalize spaces and line ends."""
        if not text:
            return ""
        # Fix hyphenated words broken across linebreaks: e.g. "com-\nputer" -> "computer"
        text = re.sub(r'(\w+)-\n(\w+)', r'\1\2', text)
        # Normalize non-breaking spaces and tabs
        text = text.replace('\xa0', ' ').replace('\t', ' ')
        # Replace multiple horizontal spaces
        text = re.sub(r'[ \t]{2,}', ' ', text)
        # Normalize 3+ newlines to 2 newlines
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    @classmethod
    def extract_with_pymupdf(cls, file_bytes: bytes) -> Tuple[str, Dict[str, Any], List[Dict[str, Any]]]:
        """
        Extract text, metadata, and structured text blocks (with font info) using PyMuPDF.
        Returns: (full_text, metadata_dict, structured_blocks)
        """
        doc = pymupdf.open(stream=file_bytes, filetype="pdf")
        page_count = len(doc)
        full_text_parts = []
        structured_blocks = []

        doc_meta = doc.metadata or {}
        extracted_title = doc_meta.get("title") or ""
        extracted_author = doc_meta.get("author") or ""

        first_page_large_spans = []

        for page_idx, page in enumerate(doc):
            page_text = page.get_text("text")
            full_text_parts.append(page_text)

            # Extract detailed block text with font size for header detection
            try:
                page_dict = page.get_text("dict")
                blocks = page_dict.get("blocks", [])
                for b in blocks:
                    if b.get("type") == 0:  # Text block
                        block_text = ""
                        max_font_size = 0.0
                        is_bold = False

                        for line in b.get("lines", []):
                            line_text = ""
                            for span in line.get("spans", []):
                                line_text += span.get("text", "")
                                size = span.get("size", 10.0)
                                if size > max_font_size:
                                    max_font_size = size
                                flags = span.get("flags", 0)
                                if flags & 2 or "bold" in span.get("font", "").lower():
                                    is_bold = True
                            block_text += line_text + " "

                        block_text = block_text.strip()
                        if block_text:
                            block_info = {
                                "page": page_idx + 1,
                                "text": block_text,
                                "font_size": max_font_size,
                                "is_bold": is_bold,
                                "bbox": b.get("bbox")
                            }
                            structured_blocks.append(block_info)
                            if page_idx == 0 and len(block_text) > 5 and len(block_text) < 250:
                                first_page_large_spans.append((max_font_size, block_text))
            except Exception:
                pass

        doc.close()
        full_text = cls.clean_text("\n\n".join(full_text_parts))

        # Infer title if metadata is blank or generic
        if not extracted_title or len(extracted_title) < 5 or "untitled" in extracted_title.lower():
            if first_page_large_spans:
                # Top largest font span on page 1 is typically the paper title
                first_page_large_spans.sort(key=lambda x: x[0], reverse=True)
                candidate_title = first_page_large_spans[0][1]
                # Filter out single words or conference headers
                if len(candidate_title.split()) >= 2:
                    extracted_title = candidate_title

        authors = []
        if extracted_author:
            authors = [a.strip() for a in re.split(r'[,;and]+', extracted_author) if a.strip()]

        metadata = {
            "title": extracted_title or "Untitled Research Paper",
            "authors": authors,
            "pages": page_count,
            "year": doc_meta.get("creationDate", "")[:4] if doc_meta.get("creationDate") else None
        }

        return full_text, metadata, structured_blocks

    @classmethod
    def extract_with_pypdf(cls, file_bytes: bytes) -> Tuple[str, Dict[str, Any], List[Dict[str, Any]]]:
        """Fallback extractor using pypdf."""
        reader = pypdf.PdfReader(io.BytesIO(file_bytes))
        page_count = len(reader.pages)
        full_text_parts = []

        for page in reader.pages:
            t = page.extract_text() or ""
            full_text_parts.append(t)

        full_text = cls.clean_text("\n\n".join(full_text_parts))
        doc_meta = reader.metadata or {}
        extracted_title = doc_meta.title or ""
        extracted_author = doc_meta.author or ""

        authors = [a.strip() for a in re.split(r'[,;and]+', extracted_author) if a.strip()] if extracted_author else []

        metadata = {
            "title": extracted_title or "Untitled Research Paper",
            "authors": authors,
            "pages": page_count,
            "year": None
        }

        return full_text, metadata, []

    @classmethod
    def extract(cls, file_bytes: bytes, filename: str = "paper.pdf") -> Tuple[str, Dict[str, Any], List[Dict[str, Any]]]:
        """
        Main extraction entry point.
        Attempts PyMuPDF first, then falls back to pypdf.
        """
        try:
            return cls.extract_with_pymupdf(file_bytes)
        except Exception as e:
            try:
                return cls.extract_with_pypdf(file_bytes)
            except Exception as e2:
                raise ValueError(f"Failed to extract text from PDF: {str(e2)}")
