import re
from typing import Dict, List, Tuple, Any, Optional

class SectionParser:
    # Standard section classification patterns
    PATTERNS = {
        "Abstract": [
            r'^(?:(?:\d+\.?\s*)?abstract(?:\s*[:—\-])?)',
            r'^executive summary',
        ],
        "Introduction": [
            r'^(?:(?:\d+\.?\s*|I\.\s*|section\s+\d+[:.]?\s*)?introduction(?:\s+and\s+(?:motivation|background))?)',
            r'^(?:(?:\d+\.?\s*|I\.\s*)?background\s+(?:and\s+overview|information)?)',
        ],
        "Methodology": [
            r'^(?:(?:\d+\.?\s*|II\.\s*|III\.\s*|IV\.\s*)?(?:methodology|methods|method|materials and methods|proposed method(?:ology)?|proposed approach|system architecture|model architecture|framework|our approach|implementation details))',
            r'^(?:(?:\d+\.?\s*|II\.\s*|III\.\s*)?experimental (?:setup|design|procedure))',
        ],
        "Results": [
            r'^(?:(?:\d+\.?\s*|IV\.\s*|V\.\s*|VI\.\s*)?(?:results|findings|empirical results|experimental results|evaluation|experiments and results|performance analysis|benchmark results|ablation studies))',
        ],
        "Conclusion": [
            r'^(?:(?:\d+\.?\s*|V\.\s*|VI\.\s*|VII\.\s*)?(?:conclusion|conclusions|concluding remarks|discussion and conclusion|conclusion and future work|summary and conclusions))',
            r'^(?:(?:\d+\.?\s*|V\.\s*|VI\.\s*)?discussion)',
        ],
        "References": [
            r'^(?:(?:\d+\.?\s*)?(?:references|bibliography|literature cited|works cited))',
        ]
    }

    @classmethod
    def match_heading_category(cls, line: str) -> Optional[Tuple[str, str]]:
        """
        Check if a single line resembles a major academic section header.
        Returns: (CanonicalCategoryName, matched_title) or None
        """
        cleaned = line.strip()
        # Header candidate shouldn't be too long or too short
        if len(cleaned) < 3 or len(cleaned) > 120:
            return None
        
        # Remove trailing colons or dots
        test_line = re.sub(r'[:.]+$', '', cleaned).strip()

        for category, regex_list in cls.PATTERNS.items():
            for pattern in regex_list:
                if re.search(pattern, test_line, re.IGNORECASE):
                    # Verify it doesn't look like a normal sentence with periods or lowercase start
                    words = test_line.split()
                    if len(words) <= 10:
                        return category, cleaned
        return None

    @classmethod
    def parse_sections(cls, full_text: str, structured_blocks: List[Dict[str, Any]] = None) -> Dict[str, Dict[str, Any]]:
        """
        Extract sections from paper text.
        Returns a dictionary keyed by section name ("Abstract", "Introduction", "Methodology", etc.)
        """
        lines = full_text.split('\n')
        detected_headers: List[Tuple[int, str, str]] = []  # (line_index, category, raw_title)

        for idx, line in enumerate(lines):
            line_str = line.strip()
            if not line_str:
                continue

            match = cls.match_heading_category(line_str)
            if match:
                cat, title = match
                # Avoid duplicate adjacent matches
                if not detected_headers or detected_headers[-1][1] != cat:
                    detected_headers.append((idx, cat, title))

        # Check for Abstract if not caught as isolated line
        has_abstract = any(h[1] == "Abstract" for h in detected_headers)
        if not has_abstract:
            abstract_match = re.search(r'(?:^|\n)(abstract[\s:\-—]+)(.*?)(?=(?:\n\s*(?:1\.?\s*)?introduction|\n\s*keywords|\n\n\s*1\s+[A-Z]))', full_text, re.IGNORECASE | re.DOTALL)
            if abstract_match:
                pass  # We can capture it directly below

        sections_dict: Dict[str, Dict[str, Any]] = {}
        raw_sections_order = []

        if detected_headers:
            for i, (line_idx, cat, title) in enumerate(detected_headers):
                start = line_idx + 1
                end = detected_headers[i + 1][0] if (i + 1 < len(detected_headers)) else len(lines)
                section_text = "\n".join(lines[start:end]).strip()

                if cat not in sections_dict or len(section_text) > len(sections_dict[cat]["text"]):
                    sections_dict[cat] = {
                        "name": cat,
                        "title": title,
                        "text": section_text,
                        "word_count": len(section_text.split()),
                        "summary": "",
                        "key_sentences": [],
                        "reading_time_min": round(len(section_text.split()) / 200.0, 1)
                    }
                    raw_sections_order.append(cat)

        # Fallback if text lacked clean line headers
        all_canonical = ["Abstract", "Introduction", "Methodology", "Results", "Conclusion", "References"]
        for cat in all_canonical:
            if cat not in sections_dict:
                # Attempt regex capture for missing section
                extracted_chunk = cls._fallback_extract_category(full_text, cat)
                if extracted_chunk:
                    sections_dict[cat] = {
                        "name": cat,
                        "title": cat,
                        "text": extracted_chunk.strip(),
                        "word_count": len(extracted_chunk.split()),
                        "summary": "",
                        "key_sentences": [],
                        "reading_time_min": round(len(extracted_chunk.split()) / 200.0, 1)
                    }

        # If still missing Abstract, extract the beginning 250 words
        if "Abstract" not in sections_dict or len(sections_dict["Abstract"]["text"]) < 50:
            words = full_text.split()
            first_chunk = " ".join(words[20:300]) if len(words) > 50 else full_text
            sections_dict["Abstract"] = {
                "name": "Abstract",
                "title": "Abstract / Summary",
                "text": first_chunk,
                "word_count": len(first_chunk.split()),
                "summary": "",
                "key_sentences": [],
                "reading_time_min": round(len(first_chunk.split()) / 200.0, 1)
            }

        # Ensure all canonical keys exist so frontend can render them gracefully
        for cat in all_canonical:
            if cat not in sections_dict:
                sections_dict[cat] = {
                    "name": cat,
                    "title": f"{cat} (Extracted or Inferred)",
                    "text": f"No explicit {cat.lower()} section was detected as an isolated header in this document.",
                    "word_count": 0,
                    "summary": f"The paper does not have a dedicated {cat.lower()} header.",
                    "key_sentences": [],
                    "reading_time_min": 0.0
                }

        return sections_dict

    @classmethod
    def _fallback_extract_category(cls, text: str, category: str) -> Optional[str]:
        regex_map = {
            "Abstract": r'(?:abstract[\s:\-—]+)([\s\S]{100,2000}?)(?=(?:introduction|keywords|1\.\s+introduction|\n\n\s*1\s+))',
            "Introduction": r'(?:introduction[\s:\-—]+)([\s\S]{150,5000}?)(?=(?:related work|methodology|methods|2\.\s+|materials and methods))',
            "Methodology": r'(?:(?:methodology|methods|proposed approach|system architecture)[\s:\-—]+)([\s\S]{150,6000}?)(?=(?:results|experiments|evaluation|4\.\s+|discussion))',
            "Results": r'(?:(?:results|evaluation|experiments and results|findings)[\s:\-—]+)([\s\S]{150,6000}?)(?=(?:discussion|conclusion|limitations|references))',
            "Conclusion": r'(?:(?:conclusion|conclusions|concluding remarks)[\s:\-—]+)([\s\S]{100,3000}?)(?=(?:references|acknowledgments|bibliography))',
            "References": r'(?:(?:references|bibliography)[\s:\-—]+)([\s\S]{100,12000})'
        }
        pat = regex_map.get(category)
        if pat:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return None
