import re
import math
from typing import Dict, List, Tuple, Any
from app.services.summarizer import PaperSummarizer

class ReadabilityAnalyzer:
    @staticmethod
    def count_syllables_word(word: str) -> int:
        """Estimate syllables in an English word."""
        w = word.lower().strip()
        if not w:
            return 0
        if len(w) <= 3:
            return 1
        # Remove common trailing non-syllabic endings
        w = re.sub(r'(?:[^laeiouy]|ed|es|e)$', '', w)
        # Count vowel sequences
        vowels = re.findall(r'[aeiouy]{1,2}', w)
        return max(1, len(vowels))

    @classmethod
    def evaluate(cls, full_text: str, sections: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluate comprehensive readability metrics and generate writing suggestions.
        """
        # Focus on body text, excluding bibliography
        body_parts = []
        for name, sec in sections.items():
            if name != "References":
                body_parts.append(sec.get("text", ""))
        analyzed_text = "\n\n".join(body_parts) if body_parts else full_text

        sentences = PaperSummarizer.split_sentences(analyzed_text)
        words = re.findall(r'\b[a-zA-Z]{1,40}\b', analyzed_text)

        num_sentences = max(1, len(sentences))
        num_words = max(1, len(words))
        total_letters = sum(len(w) for w in words)

        # Count syllables and complex words (>= 3 syllables)
        syllables_list = [cls.count_syllables_word(w) for w in words]
        total_syllables = sum(syllables_list)
        complex_words = sum(1 for syl in syllables_list if syl >= 3)

        # Average metrics
        asl = round(num_words / num_sentences, 2)  # Average Sentence Length
        asw = round(total_syllables / num_words, 2)  # Average Syllables per Word
        complex_pct = round((complex_words / num_words) * 100, 2)

        # 1. Flesch Reading Ease
        fre = 206.835 - (1.015 * asl) - (84.6 * asw)
        fre = round(max(0.0, min(100.0, fre)), 1)
        if fre >= 70:
            fre_interp = "Standard / Accessible"
            fre_bench = "Easy for general public"
        elif fre >= 50:
            fre_interp = "Fairly Difficult / College Level"
            fre_bench = "Undergraduate text level"
        elif fre >= 30:
            fre_interp = "Difficult / Academic Level"
            fre_bench = "Typical peer-reviewed paper"
        else:
            fre_interp = "Very Difficult / Specialized Academic"
            fre_bench = "Dense academic / scientific paper"

        # 2. Flesch-Kincaid Grade Level
        fk_grade = (0.39 * asl) + (11.8 * asw) - 15.59
        fk_grade = round(max(1.0, min(22.0, fk_grade)), 1)
        fk_level_str = f"Grade {fk_grade:.1f}" if fk_grade < 13 else ("Undergraduate (13-16)" if fk_grade <= 16 else "Graduate / Postgrad (17+)")

        # 3. Gunning Fog Index
        gunning_fog = 0.4 * (asl + complex_pct)
        gunning_fog = round(max(1.0, min(25.0, gunning_fog)), 1)
        fog_level_str = f"Level {gunning_fog:.1f}"

        # 4. Coleman-Liau Index
        # L = average letters per 100 words, S = average sentences per 100 words
        L = (total_letters / num_words) * 100
        S = (num_sentences / num_words) * 100
        coleman_liau = (0.0588 * L) - (0.296 * S) - 15.8
        coleman_liau = round(max(1.0, min(22.0, coleman_liau)), 1)

        # 5. Automated Readability Index (ARI)
        ari = (4.71 * (total_letters / num_words)) + (0.5 * asl) - 21.43
        ari = round(max(1.0, min(25.0, ari)), 1)

        # 6. SMOG Index (Simple Measure of Gobbledygook)
        # Formula: 1.0430 * sqrt(30 * complex_words / sentences) + 3.1291
        smog = 1.0430 * math.sqrt(30 * (complex_words / num_sentences)) + 3.1291 if complex_words > 0 else 8.0
        smog = round(max(1.0, min(25.0, smog)), 1)

        # 7. Lexical Diversity (Type-Token Ratio)
        unique_words = len(set(w.lower() for w in words))
        ttr = round(unique_words / num_words, 3)

        # 8. Academic Tone Score (0-100)
        # Academic writing has moderate-to-high complex words (15-28%), high lexical diversity, and avg sentence length of 20-28 words.
        tone_score = 65.0
        if 18 <= asl <= 30:
            tone_score += 15.0
        elif asl > 35:
            tone_score -= 10.0
        if 18 <= complex_pct <= 32:
            tone_score += 15.0
        if ttr >= 0.25:
            tone_score += 5.0
        tone_score = round(min(98.0, max(40.0, tone_score)), 1)

        # Overall level description
        if fk_grade >= 16:
            overall_reading_level = "Postgraduate / Expert Scientific Level"
        elif fk_grade >= 13:
            overall_reading_level = "University / Scholarly Research Level"
        else:
            overall_reading_level = "General Academic / High School Level"

        # 9. Smart writing suggestions
        suggestions = []

        # Sentence length check
        long_sentences = [s for s in sentences if len(s.split()) >= 38]
        if long_sentences:
            suggestions.append(
                f"Found {len(long_sentences)} sentences with over 38 words. Consider splitting complex compound sentences to improve reader comprehension."
            )

        if asl > 28:
            suggestions.append(
                f"Average sentence length is {asl} words (typical academic target: 20-25 words). Breaking up nested clauses will make arguments sharper."
            )
        elif asl < 14:
            suggestions.append(
                f"Average sentence length is relatively short ({asl} words). Combining related points into cohesive compound structures can improve academic flow."
            )

        if complex_pct > 32:
            suggestions.append(
                f"Complex word density is high ({complex_pct}%). While technical terminology is expected, ensure jargon does not obscure core methodological insights."
            )
        elif complex_pct < 15:
            suggestions.append(
                f"Vocabulary complexity is low for academic writing ({complex_pct}%). Consider employing more domain-specific, precise technical terminology."
            )

        if fre < 25:
            suggestions.append(
                "Flesch Reading Ease is under 25 (very dense). Use bullet points, bold emphasis for key takeaways, and transitional topic sentences in dense paragraphs."
            )

        if ttr < 0.20 and num_words > 1000:
            suggestions.append(
                f"Lexical diversity (TTR = {ttr}) indicates recurring phrasing. Varying technical descriptors can enrich the manuscript's presentation."
            )

        # Default positive reinforcement if paper is well-balanced
        if not suggestions:
            suggestions.append("Sentence length and technical vocabulary are well-balanced for scholarly peer-reviewed dissemination.")

        return {
            "flesch_reading_ease": {
                "score": fre,
                "grade_level": "N/A (Score 0-100)",
                "interpretation": fre_interp,
                "benchmark": fre_bench
            },
            "flesch_kincaid_grade": {
                "score": fk_grade,
                "grade_level": fk_level_str,
                "interpretation": "Years of education required to comfortably understand the text.",
                "benchmark": "Scholarly average: Grade 13.0 - 16.5"
            },
            "gunning_fog": {
                "score": gunning_fog,
                "grade_level": fog_level_str,
                "interpretation": "Estimates years of formal education required on first reading.",
                "benchmark": "Academic average: 14.0 - 18.0"
            },
            "coleman_liau": {
                "score": coleman_liau,
                "grade_level": f"Grade {coleman_liau:.1f}",
                "interpretation": "Gauges reading level using letter count and sentence frequency.",
                "benchmark": "Academic average: Grade 12.0 - 16.0"
            },
            "automated_readability_index": {
                "score": ari,
                "grade_level": f"Grade {ari:.1f}",
                "interpretation": "Evaluates readability using character density.",
                "benchmark": "Academic average: Grade 13.0 - 17.0"
            },
            "smog_index": {
                "score": smog,
                "grade_level": f"Grade {smog:.1f}",
                "interpretation": "Evaluates text comprehension requirements based on polysyllabic words.",
                "benchmark": "Academic average: Grade 13.0 - 17.0"
            },
            "average_sentence_length": asl,
            "average_syllables_per_word": asw,
            "complex_words_percentage": complex_pct,
            "lexical_diversity_ttr": ttr,
            "academic_tone_score": tone_score,
            "overall_reading_level": overall_reading_level,
            "writing_suggestions": suggestions
        }
