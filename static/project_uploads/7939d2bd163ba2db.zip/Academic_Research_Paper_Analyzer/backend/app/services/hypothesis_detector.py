import re
from typing import Dict, List, Any, Optional
from app.services.summarizer import PaperSummarizer

class HypothesisDetector:
    HYPOTHESIS_PATTERNS = [
        (r'\b(?:we|our)\s+hypothesize\s+that\b', 1.0, "Explicit Hypothesis"),
        (r'\b(?:our|the)\s+(?:central|primary|main)\s+hypothesis\s+is\s+that\b', 1.0, "Central Hypothesis"),
        (r'\bwe\s+test\s+(?:the\s+hypothesis\s+that|whether)\b', 0.95, "Hypothesis Testing"),
        (r'\bunder\s+the\s+hypothesis\s+that\b', 0.85, "Conditional Hypothesis"),
        (r'\bwe\s+(?:posit|conjecture|surmise)\s+that\b', 0.85, "Theoretical Posit"),
        (r'\bwe\s+anticipate\s+that\b', 0.7, "Anticipation"),
        (r'\bwe\s+expect\s+that\b', 0.65, "Expectation"),
    ]

    QUESTION_PATTERNS = [
        r'\b(?:we\s+investigate|we\s+examine|we\s+explore)\s+(?:whether|how|if)\b',
        r'\b(?:this\s+paper|this\s+study|this\s+work)\s+(?:addresses|investigates|examines)\s+(?:the\s+question\s+of|whether|how)\b',
        r'\bwe\s+address\s+the\s+following\s+(?:research\s+)?questions?\b',
        r'\bthe\s+central\s+question\s+(?:is|we\s+ask)\b',
        r'\bcan\s+[a-z\s]+\s+improve\b',
        r'\bhow\s+does\s+[a-z\s]+\s+affect\b',
        r'\bto\s+what\s+extent\s+does\b'
    ]

    OBJECTIVE_PATTERNS = [
        r'\b(?:the\s+goal|the\s+objective|the\s+aim)\s+of\s+this\s+(?:paper|study|work|research)\s+is\s+to\b',
        r'\b(?:this\s+paper|this\s+work|this\s+study)\s+aims\s+to\b',
        r'\bwe\s+aim\s+to\b',
        r'\bour\s+primary\s+goal\s+is\s+to\b',
        r'\bwe\s+seek\s+to\b'
    ]

    PROBLEM_PATTERNS = [
        r'\b(?:the\s+main|a\s+major|a\s+fundamental|the\s+primary)\s+(?:challenge|problem|limitation|drawback|bottleneck)\b',
        r'\bexisting\s+(?:methods|approaches|models|techniques|works)\s+(?:suffer\s+from|fail\s+to|struggle\s+with|are\s+limited\s+by)\b',
        r'\bremains\s+a\s+(?:challenging|unresolved|open)\s+(?:problem|issue|task)\b',
        r'\bhowever,\s+(?:little\s+is\s+known|current\s+methods)\b',
        r'\bto\s+overcome\s+this\s+limitation\b'
    ]

    @classmethod
    def analyze(cls, full_text: str, sections: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Detects primary hypothesis, research questions, core objectives, and problem statement.
        """
        # Focus search on Introduction, Abstract, and Methodology, where questions & hypotheses live
        intro_text = sections.get("Introduction", {}).get("text", "")
        abstract_text = sections.get("Abstract", {}).get("text", "")
        methods_text = sections.get("Methodology", {}).get("text", "")

        priority_text = f"{abstract_text}\n\n{intro_text}\n\n{methods_text}"
        all_sentences = PaperSummarizer.split_sentences(priority_text if len(priority_text) > 200 else full_text)

        hypothesis_candidates = []
        research_questions = []
        core_objectives = []
        problem_statement = None
        methodological_claims = []

        for s in all_sentences:
            s_clean = s.strip()
            if len(s_clean) < 25 or len(s_clean) > 400:
                continue

            # 1. Check for explicit hypothesis
            for pat, weight, cue_type in cls.HYPOTHESIS_PATTERNS:
                if re.search(pat, s_clean, re.IGNORECASE):
                    hypothesis_candidates.append({
                        "sentence": s_clean,
                        "score": weight,
                        "cue_type": cue_type,
                        "context": None
                    })
                    break

            # 2. Check for research questions (explicit ? or semantic question cue)
            if s_clean.endswith('?'):
                # Academic question
                if s_clean not in research_questions and len(s_clean.split()) >= 5:
                    research_questions.append(s_clean)
            else:
                for q_pat in cls.QUESTION_PATTERNS:
                    if re.search(q_pat, s_clean, re.IGNORECASE):
                        if s_clean not in research_questions:
                            research_questions.append(s_clean)
                        break

            # 3. Check for core objectives
            for obj_pat in cls.OBJECTIVE_PATTERNS:
                if re.search(obj_pat, s_clean, re.IGNORECASE):
                    if s_clean not in core_objectives:
                        core_objectives.append(s_clean)
                    break

            # 4. Check for problem statement
            if not problem_statement:
                for prob_pat in cls.PROBLEM_PATTERNS:
                    if re.search(prob_pat, s_clean, re.IGNORECASE):
                        problem_statement = s_clean
                        break

            # 5. Methodological claim
            if re.search(r'\b(?:we\s+demonstrate\s+that|our\s+approach\s+outperforms|we\s+show\s+empirically)\b', s_clean, re.IGNORECASE):
                if s_clean not in methodological_claims:
                    methodological_claims.append(s_clean)

        # Sort hypothesis candidates by confidence score
        hypothesis_candidates.sort(key=lambda x: x["score"], reverse=True)

        primary_hypothesis = None
        confidence = 0.0

        if hypothesis_candidates:
            primary_hypothesis = hypothesis_candidates[0]["sentence"]
            confidence = hypothesis_candidates[0]["score"]
        elif core_objectives:
            # If no sentence explicitly used the word "hypothesis", the core objective is formulated as the central research thesis
            primary_hypothesis = core_objectives[0]
            confidence = 0.75
            hypothesis_candidates.append({
                "sentence": primary_hypothesis,
                "score": 0.75,
                "cue_type": "Primary Research Objective / Thesis",
                "context": None
            })
        elif research_questions:
            primary_hypothesis = f"Investigates: {research_questions[0]}"
            confidence = 0.70
        else:
            # Fallback to key sentence from abstract
            _, abs_keys = PaperSummarizer.summarize_section(abstract_text or full_text, max_sentences=1)
            if abs_keys:
                primary_hypothesis = abs_keys[0]
                confidence = 0.60

        return {
            "primary_hypothesis": primary_hypothesis,
            "hypothesis_confidence": round(confidence, 2),
            "hypothesis_candidates": hypothesis_candidates[:5],
            "research_questions": research_questions[:6],
            "core_objectives": core_objectives[:5],
            "problem_statement": problem_statement or "The research aims to address current limitations and establish empirical improvements in this domain.",
            "methodological_claims": methodological_claims[:4]
        }
