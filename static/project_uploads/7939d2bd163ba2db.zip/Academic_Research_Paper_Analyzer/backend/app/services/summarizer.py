import re
import math
from collections import Counter
from typing import List, Dict, Tuple, Set, Any

class PaperSummarizer:
    # Common academic stopwords
    STOPWORDS: Set[str] = {
        "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", 
        "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", 
        "by", "can", "cannot", "could", "did", "do", "does", "doing", "down", "during", "each", 
        "few", "for", "from", "further", "had", "has", "have", "having", "he", "her", "here", 
        "hers", "herself", "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", 
        "its", "itself", "me", "more", "most", "my", "myself", "no", "nor", "not", "of", "off", 
        "on", "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", 
        "own", "same", "she", "should", "so", "some", "such", "than", "that", "the", "their", 
        "theirs", "them", "themselves", "then", "there", "these", "they", "this", "those", 
        "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", 
        "when", "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", 
        "yours", "yourself", "yourselves", "also", "et", "al", "fig", "table", "paper", "study",
        "using", "used", "based", "shown", "show", "shows", "well", "one", "two", "see", "may"
    }

    @classmethod
    def split_sentences(cls, text: str) -> List[str]:
        """Split text into sentences while respecting common academic abbreviations."""
        if not text:
            return []
        # Protect abbreviations like e.g., i.e., et al., Fig., Eq., Dr., Prof., vs.
        protected = text
        protected = re.sub(r'\b(e\.g\.|i\.e\.|et al\.|Fig\.|Eq\.|Dr\.|Prof\.|vs\.|ref\.|no\.)', lambda m: m.group(0).replace('.', '___DOT___'), protected, flags=re.IGNORECASE)
        # Protect citation brackets with numbers or dots
        protected = re.sub(r'\[\s*\d+(?:\s*,\s*\d+)*\s*\]', lambda m: m.group(0).replace('.', '___DOT___'), protected)

        raw_sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z0-9"\'(\[])', protected)
        sentences = []
        for s in raw_sentences:
            s_clean = s.replace('___DOT___', '.').strip()
            # Filter out header artifacts, page numbers, or noise
            if len(s_clean) >= 20 and len(s_clean.split()) >= 4:
                sentences.append(s_clean)
        return sentences

    @classmethod
    def tokenize(cls, text: str) -> List[str]:
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        return [w for w in words if w not in cls.STOPWORDS]

    @classmethod
    def summarize_section(cls, text: str, max_sentences: int = 3) -> Tuple[str, List[str]]:
        """
        Extractive summarizer for a section using TextRank / TF-IDF scoring.
        Returns: (summary_paragraph, list_of_key_sentences)
        """
        sentences = cls.split_sentences(text)
        if not sentences:
            return text[:300] + "..." if len(text) > 300 else text, []
        if len(sentences) <= max_sentences:
            return " ".join(sentences), sentences

        # 1. Compute word frequencies
        word_freq = Counter()
        sentence_words = []
        for s in sentences:
            w = cls.tokenize(s)
            sentence_words.append(w)
            word_freq.update(w)

        if not word_freq:
            return " ".join(sentences[:max_sentences]), sentences[:max_sentences]

        max_f = max(word_freq.values())
        norm_freq = {k: v / max_f for k, v in word_freq.items()}

        # 2. Score sentences
        scored_sentences = []
        total_s = len(sentences)
        for idx, s in enumerate(sentences):
            words = sentence_words[idx]
            if not words:
                continue

            # TF-IDF like sum
            raw_score = sum(norm_freq.get(w, 0) for w in words) / (math.log(len(words) + 1) + 1e-5)

            # Position bias (academic text puts crucial claims in first 20% or last 10%)
            pos_ratio = idx / total_s
            pos_boost = 1.3 if (pos_ratio < 0.2 or pos_ratio > 0.85) else 1.0

            # Academic cue boost
            cue_boost = 1.0
            lower_s = s.lower()
            if any(cue in lower_s for cue in ["we propose", "we introduce", "our results", "we demonstrate", "significantly", "in contrast", "we show", "our approach"]):
                cue_boost = 1.4

            final_score = raw_score * pos_boost * cue_boost
            scored_sentences.append((final_score, idx, s))

        # Select top sentences
        scored_sentences.sort(key=lambda x: x[0], reverse=True)
        top_selected = scored_sentences[:max_sentences]

        # Re-order by chronological flow in document
        top_selected.sort(key=lambda x: x[1])

        key_sentences = [item[2] for item in top_selected]
        summary_paragraph = " ".join(key_sentences)
        return summary_paragraph, key_sentences

    @classmethod
    def extract_contributions(cls, full_text: str, intro_text: str = "") -> List[str]:
        """Detect explicit contribution statements in the paper."""
        target_text = intro_text if (intro_text and len(intro_text) > 200) else full_text
        sentences = cls.split_sentences(target_text)

        contribution_cues = [
            r'our main contribution',
            r'the main contribution',
            r'our contributions are',
            r'we make the following contribution',
            r'in this paper, we propose',
            r'in this work, we introduce',
            r'we present a novel',
            r'to our knowledge, this is the first',
            r'we propose a novel',
            r'we design and evaluate',
            r'we formulate',
            r'our proposed method'
        ]

        contributions = []
        for s in sentences:
            s_clean = s.strip()
            for cue in contribution_cues:
                if re.search(cue, s_clean, re.IGNORECASE):
                    if s_clean not in contributions and len(s_clean) < 350:
                        contributions.append(s_clean)
                        break

        # Fallback: check bullet points or numbered lists in introduction
        if not contributions and intro_text:
            bullet_matches = re.findall(r'(?:^|\n)\s*(?:[•\-\*]|\d+\.)\s*([A-Z][^\n]{30,250}\.)', intro_text)
            if bullet_matches:
                contributions = bullet_matches[:4]

        # If still empty, return top 2 salient intro sentences
        if not contributions:
            _, key_intro = cls.summarize_section(intro_text or full_text, max_sentences=2)
            contributions = key_intro

        return contributions[:5]

    @classmethod
    def generate_executive_summary(cls, sections: Dict[str, Dict[str, Any]], full_text: str) -> str:
        """
        Generate an Executive TL;DR synthesizing Abstract, Key Contributions, and Conclusion.
        """
        abstract_text = sections.get("Abstract", {}).get("text", "")
        conclusion_text = sections.get("Conclusion", {}).get("text", "")
        results_text = sections.get("Results", {}).get("text", "")

        parts = []

        # 1. Distill abstract
        if abstract_text and len(abstract_text) > 60:
            abs_summary, _ = cls.summarize_section(abstract_text, max_sentences=2)
            parts.append(abs_summary)

        # 2. Add key finding from results or conclusion
        finding_source = results_text if (results_text and len(results_text) > 100) else conclusion_text
        if finding_source and len(finding_source) > 60:
            finding_summary, _ = cls.summarize_section(finding_source, max_sentences=2)
            parts.append(finding_summary)

        if not parts:
            # Fallback on overall text
            exec_summary, _ = cls.summarize_section(full_text, max_sentences=3)
            return exec_summary

        return " ".join(parts)
