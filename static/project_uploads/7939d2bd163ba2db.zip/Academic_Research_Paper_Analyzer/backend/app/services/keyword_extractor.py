import re
from collections import Counter
from typing import List, Dict, Any, Tuple
from app.services.summarizer import PaperSummarizer

class KeywordExtractor:
    ACADEMIC_STOPWORDS = PaperSummarizer.STOPWORDS | {
        "author", "authors", "section", "table", "figure", "page", "result", "results", 
        "data", "dataset", "datasets", "approach", "method", "methods", "model", "models", 
        "proposed", "paper", "study", "work", "analysis", "system", "systems", "based", 
        "different", "number", "performance", "high", "low", "time", "large", "small",
        "order", "given", "used", "using", "first", "second", "third", "main", "well",
        "state", "art", "level", "case", "cases", "task", "tasks", "set", "sets"
    }

    METHOD_SUFFIXES = [
        "algorithm", "network", "networks", "architecture", "mechanism", "transformer", 
        "classifier", "regressor", "pipeline", "framework", "optimizer", "encoder", "decoder",
        "layer", "attention", "module"
    ]

    METRIC_KEYWORDS = [
        "accuracy", "f1", "bleu", "rouge", "auc", "roc", "precision", "recall", 
        "loss", "perplexity", "latency", "throughput", "error rate", "convergence"
    ]

    @classmethod
    def categorize_term(cls, term: str) -> str:
        term_lower = term.lower()
        if any(m in term_lower for m in cls.METRIC_KEYWORDS):
            return "Metric/Evaluation"
        elif any(s in term_lower for s in cls.METHOD_SUFFIXES):
            return "Method/Algorithm"
        elif any(d in term_lower for d in ["benchmark", "corpus", "imagenet", "squad", "wmt", "glue"]):
            return "Dataset/Benchmark"
        elif len(term_lower.split()) > 1:
            return "Key Concept"
        return "Domain Term"

    @classmethod
    def extract_ngrams(cls, words: List[str], n: int) -> List[str]:
        ngrams = []
        for i in range(len(words) - n + 1):
            chunk = words[i:i+n]
            # Valid n-gram: first and last words must not be stop words
            if chunk[0] not in cls.ACADEMIC_STOPWORDS and chunk[-1] not in cls.ACADEMIC_STOPWORDS:
                phrase = " ".join(chunk)
                ngrams.append(phrase)
        return ngrams

    @classmethod
    def extract(cls, full_text: str, sections: Dict[str, Dict[str, Any]], top_k: int = 24) -> List[Dict[str, Any]]:
        """
        Extract key technical terms, multi-word concepts, frequencies, and example contexts.
        """
        sentences = PaperSummarizer.split_sentences(full_text)
        
        # Tokenize cleaned words
        raw_words = re.findall(r'\b[a-zA-Z][a-zA-Z\-]{2,}\b', full_text.lower())
        
        # 1. Unigrams
        filtered_unigrams = [w for w in raw_words if w not in cls.ACADEMIC_STOPWORDS and len(w) > 3]
        unigram_counts = Counter(filtered_unigrams)

        # 2. Bigrams
        bigrams = cls.extract_ngrams(raw_words, 2)
        bigram_counts = Counter(bigrams)

        # 3. Trigrams
        trigrams = cls.extract_ngrams(raw_words, 3)
        trigram_counts = Counter(trigrams)

        # Combine candidates with phrase weighting
        candidates: Dict[str, int] = {}

        # Multi-word technical concepts are much more informative in research papers
        for phrase, count in trigram_counts.items():
            if count >= 2:
                candidates[phrase] = count * 3

        for phrase, count in bigram_counts.items():
            if count >= 3:
                # Don't double count if part of frequent trigram
                candidates[phrase] = count * 2

        for word, count in unigram_counts.items():
            if count >= 4 and len(word) >= 4:
                candidates[word] = count

        if not candidates:
            # Fallback to top unigrams
            for word, count in unigram_counts.most_common(top_k):
                candidates[word] = count

        # Sort by composite score
        sorted_terms = sorted(candidates.items(), key=lambda x: x[1], reverse=True)[:top_k]

        max_score = sorted_terms[0][1] if sorted_terms else 1.0

        results = []
        for term, weighted_val in sorted_terms:
            # Actual raw frequency in text
            pattern = re.compile(rf'\b{re.escape(term)}\b', re.IGNORECASE)
            actual_count = len(pattern.findall(full_text))

            # Find representative example context sentence
            example_sentence = None
            for s in sentences:
                if pattern.search(s) and 25 <= len(s) <= 220:
                    example_sentence = s.strip()
                    break

            category = cls.categorize_term(term)
            relevance = round(min(1.0, weighted_val / max_score), 2)

            results.append({
                "term": term.title() if len(term.split()) > 1 else term,
                "frequency": actual_count or 1,
                "relevance_score": relevance,
                "category": category,
                "example_context": example_sentence
            })

        return results
