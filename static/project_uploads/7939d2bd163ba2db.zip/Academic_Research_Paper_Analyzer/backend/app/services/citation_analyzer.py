import re
from typing import Dict, List, Tuple, Any, Optional
from app.services.summarizer import PaperSummarizer

class CitationAnalyzer:
    NUMBERED_REGEX = r'\[\s*(\d+(?:\s*(?:,\s*|-|–)\s*\d+)*)\s*\]'
    AUTHOR_YEAR_REGEX = r'\(([A-Z][a-zA-Z\s\.\-]+(?:et al\.)?,\s*(?:19|20)\d{2}[a-z]?(?:;\s*[A-Z][a-zA-Z\s\.\-]+(?:et al\.)?,\s*(?:19|20)\d{2}[a-z]?)*)\)'

    @classmethod
    def classify_intent(cls, context_sentence: str) -> str:
        s_lower = context_sentence.lower()
        if any(w in s_lower for w in ["outperform", "compared to", "baseline", "state of the art", "sota", "versus", "vs.", "better than", "higher than"]):
            return "Comparison / Benchmark"
        elif any(w in s_lower for w in ["we use", "we adopt", "following", "implemented using", "based on the algorithm", "architecture of", "method proposed by", "technique from"]):
            return "Methodology / Tool Use"
        elif any(w in s_lower for w in ["theoretical", "framework", "proved by", "foundation", "axiom", "formalized by"]):
            return "Foundational Theory"
        elif any(w in s_lower for w in ["consistent with", "in agreement with", "contrary to", "supports our"]):
            return "Discussion / Agreement"
        return "Background / Prior Art"

    @classmethod
    def parse_references_section(cls, references_text: str) -> List[str]:
        """Split bibliography text into discrete reference items."""
        if not references_text:
            return []

        # Try splitting by numbered patterns: [1], [2] or 1., 2.
        lines = references_text.split('\n')
        entries = []
        current_entry = ""

        # Check if items begin with [1] or 1.
        has_numbered_brackets = bool(re.search(r'^\s*\[\d+\]', references_text, re.MULTILINE))
        has_numbered_dots = bool(re.search(r'^\s*\d+\.\s+[A-Z]', references_text, re.MULTILINE))

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            is_new_entry = False
            if has_numbered_brackets and re.match(r'^\[\d+\]', line_str):
                is_new_entry = True
            elif has_numbered_dots and re.match(r'^\d+\.\s+[A-Z]', line_str):
                is_new_entry = True
            elif not has_numbered_brackets and not has_numbered_dots:
                # Check for author names at start of line with hanging indent or year
                if re.match(r'^[A-Z][a-zA-Z\s\.\-]{2,30}(?:et al\.)?.*?(?:19|20)\d{2}', line_str):
                    is_new_entry = True

            if is_new_entry and current_entry:
                entries.append(current_entry.strip())
                current_entry = line_str
            else:
                if current_entry:
                    current_entry += " " + line_str
                else:
                    current_entry = line_str

        if current_entry:
            entries.append(current_entry.strip())

        # Cleanup and validate entries
        cleaned = [e for e in entries if len(e) >= 15]
        return cleaned[:80]

    @classmethod
    def analyze(cls, full_text: str, sections: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract citations, their contexts, and match them with bibliography entries.
        """
        ref_text = sections.get("References", {}).get("text", "")
        references_list = cls.parse_references_section(ref_text)

        # Create quick lookup map for numbered references
        ref_map: Dict[str, str] = {}
        for r in references_list:
            num_match = re.match(r'^\[?(\d+)\]?\.?\s*(.*)', r)
            if num_match:
                ref_map[num_match.group(1)] = r

        citations: List[Dict[str, Any]] = []
        unique_markers = set()
        total_found = 0

        # Scan each section's text (excluding References section itself to avoid false positives)
        for sec_name, sec_data in sections.items():
            if sec_name == "References":
                continue

            sec_text = sec_data.get("text", "")
            sentences = PaperSummarizer.split_sentences(sec_text)

            for s in sentences:
                s_clean = s.strip()
                # 1. Numbered citations: [1], [2, 3], [4-6]
                num_matches = list(re.finditer(cls.NUMBERED_REGEX, s_clean))
                for m in num_matches:
                    raw_bracket = m.group(0)
                    inner = m.group(1)
                    total_found += 1
                    unique_markers.add(raw_bracket)

                    # Extract discrete numbers: e.g. "1, 2" or "3-5"
                    ref_match_str = None
                    parts = re.split(r'[,–\-]+', inner)
                    for p in parts:
                        num_str = p.strip()
                        if num_str in ref_map:
                            ref_match_str = ref_map[num_str]
                            break

                    citations.append({
                        "id": f"cit_{len(citations) + 1}",
                        "key": raw_bracket,
                        "context": s_clean,
                        "section": sec_name,
                        "intent": cls.classify_intent(s_clean),
                        "reference_match": ref_match_str
                    })

                # 2. Author-year citations: (Smith et al., 2020)
                author_matches = list(re.finditer(cls.AUTHOR_YEAR_REGEX, s_clean))
                for m in author_matches:
                    raw_cit = m.group(0)
                    total_found += 1
                    unique_markers.add(raw_cit)

                    # Match author name in references
                    author_first = re.split(r'[\s,]', m.group(1))[0]
                    matched_ref = None
                    for r in references_list:
                        if author_first.lower() in r.lower():
                            matched_ref = r
                            break

                    citations.append({
                        "id": f"cit_{len(citations) + 1}",
                        "key": raw_cit,
                        "context": s_clean,
                        "section": sec_name,
                        "intent": cls.classify_intent(s_clean),
                        "reference_match": matched_ref
                    })

        # Calculate metrics
        total_words = sum(s.get("word_count", 0) for name, s in sections.items() if name != "References") or 1
        density = round((total_found / total_words) * 1000, 2)
        style = "Numbered [1]" if any(c["key"].startswith("[") for c in citations) else "Author-Year (Author, Year)"

        # Sort and deduplicate context highlights for best representation
        # Limit to top 50 citation instances to keep JSON responsive
        return {
            "total_citations_found": total_found,
            "unique_citation_markers": len(unique_markers),
            "citation_density_per_1000_words": density,
            "citations": citations[:60],
            "references": references_list,
            "citation_style": style
        }
